# -*- coding: utf-8 -*-
"""Чат 181 · признак «помещение с выходом наружу».

Повод — вопрос Дмитрия от 18.08 «добавить в перечень подъезд/улица» и его же
уточнение 23.08: «5.1 помечать помещение с выходом наружу». Бывают квартиры
с двумя выходами; знать, какое помещение выходит наружу, нужно и для порядка
работ (выход заливается последним — это уже написано в подсказке опроса), и для
сметы: входная дверь считается не так, как межкомнатная.

Ключевое различие, без которого признак бессмысленен: ВЫХОД — это дверь или
открытый проём наружу. Окно на улицу выходом не является, хотя сторона у него
тоже внешняя. Панель уже знает стороны из схемы проёмов, поэтому в девяти
случаях из десяти признак не нужно спрашивать — он вычисляется. Ручная пометка
оставлена для объекта, где схемы ещё нет.
"""
import io, hashlib, sys

ФАЙЛ = sys.argv[1] if len(sys.argv) > 1 else '/tmp/panel_181_10.html'
т = io.open(ФАЙЛ, encoding='utf-8').read()
было = len(т.encode('utf-8'))

def замена(старое, новое, имя):
    global т
    n = т.count(старое)
    assert n == 1, f'{имя}: вхождений {n}, а нужно ровно 1'
    т = т.replace(старое, новое, 1)
    print(f'  ✓ {имя}')

# ── 1. Вычисление и ручная пометка ─────────────────────────────────────────
старое1 = """const NO_FLOOR = "__no_floor";"""
новое1 = """/* ── Выход наружу [181, ответ Дмитрия «5.1 помечать помещение с выходом наружу»] ──
   Выход — дверь или открытый проём во внешнюю сторону. Окно на улицу выходом
   не считается: через него не входят, и входной двери оно не заменяет. Стороны
   «подъезд» и «улица» приходят из разбора голоса и схемы проёмов — там они
   заведены давно, а вот у ПОМЕЩЕНИЯ признака не было.

   Дом ручной пометки — план профиля, ключ `__exit`: та же форма, что у
   `__no_floor` (180), и по той же причине — схема базы не трогается, решение
   обратимо одним нажатием. */
const EXIT_KEY = "__exit";
const ВНЕШНИЕ = /подъезд|улиц|двор|лестни|тамбур/i;

function roomHasExit(rc){
  try{
    /* Ручная пометка сильнее вычисленной: человек видит квартиру, мы — данные. */
    if(typeof roomNo === "function" && roomNo(rc, EXIT_KEY)) return true;
    const r = (D.rooms || []).find(x => x.code === rc || x.name === rc || x.title === rc);
    const имя = r ? String(r.name || r.title || "") : String(rc || "");
    const свои = (typeof elemAll === "function" ? elemAll() : []).filter(e =>
      String(e.a || "") === имя || String(e.b || "") === имя ||
      String(e.a || "") === rc || String(e.b || "") === rc);
    return свои.some(e => {
      const другой = (String(e.a||"") === имя || String(e.a||"") === rc) ? String(e.b||"") : String(e.a||"");
      if(!ВНЕШНИЕ.test(другой)) return false;
      const факт = String(e.fact || "").trim();
      return факт === "дверь" || факт === "проём";      // окно — не выход
    });
  }catch(e){ return false; }
}
function roomExitSet(rc, вкл){
  try{ if(typeof roomNoSet === "function") return roomNoSet(rc, EXIT_KEY, вкл); }catch(e){}
}
function roomExitToggle(rc){
  const было = (typeof roomNo === "function") && roomNo(rc, EXIT_KEY);
  roomExitSet(rc, !было);
  toast(было ? "Пометка выхода снята" : "Помечено: из этого помещения есть выход наружу");
  try{ render(); }catch(e){}
}

const NO_FLOOR = "__no_floor";"""
замена(старое1, новое1, '1. вычисление и ручная пометка')

# ── 2. Показ в карточке помещения ──────────────────────────────────────────
старое2 = """      ((function(){
        const нет = (typeof roomNoFloor === 'function') && roomNoFloor(r.code);
        return '<div class="m" style="margin-top:8px">' +"""
новое2 = """      /* [181] Выход наружу — рядом с признаком «нет пола и потолка»: оба про то,
         чем это помещение отличается от обычной комнаты. */
      ((function(){
        const есть = (typeof roomHasExit === 'function') && roomHasExit(r.code);
        const руч = (typeof roomNo === 'function') && roomNo(r.code, EXIT_KEY);
        return '<div class="m" style="margin-top:8px">' +
          (есть ? '<span style="color:#30d158">🚪 Выход наружу</span>' +
                  (руч ? ' · отмечено вами' : ' · видно по схеме проёмов') + ' · ' : '') +
          '<button onclick="roomExitToggle(\\'' + esc(r.code) + '\\')" ' +
          'style="padding:6px 10px;border-radius:9px;border:0;background:#3a3a3c;color:#fff;font-size:13px">' +
          (руч ? 'Снять пометку выхода' : (есть ? 'Это не выход' : 'Отсюда есть выход наружу')) + '</button></div>';
      })()) +
      ((function(){
        const нет = (typeof roomNoFloor === 'function') && roomNoFloor(r.code);
        return '<div class="m" style="margin-top:8px">' +"""
замена(старое2, новое2, '2. показ в карточке помещения')

# ── 3. Метка сборки ────────────────────────────────────────────────────────
старая = 'const BUILD = "181.10";'
assert т.count(старая) == 1
т = т.replace(старая, 'const BUILD = "181.11";', 1)
print('  ✓ 3. метка сборки: 181.10 → 181.11')

io.open(ФАЙЛ, 'w', encoding='utf-8').write(т)
стало = len(т.encode('utf-8'))
sha = hashlib.sha256(io.open(ФАЙЛ, 'rb').read()).hexdigest()[:16]
print(f'\nфайл: {было} → {стало} б (+{стало-было}), sha16 {sha}')
