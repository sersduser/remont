/*
  Стенд Д-181-5 — панель сама узнаёт техническую полость.

  Повод: живой проход 23.08, свод демонтажа по девяти помещениям Юнусабада.
  Слова Дмитрия: «Всё верно, кроме шахты». Шахте (0,81 м²) предлагался демонтаж
  покрытия пола и потолка, которых у неё нет. Признак есть с 180.9, но живёт на
  другом экране — человек про него не вспомнит.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 у помещения площадью меньше 1,5 м² предложение есть;
    С.2 у обычного помещения (16 м²) предложения нет — не мешаем;
    С.3 имя «Короб» опознаётся даже при большой площади;
    С.4 когда признак уже стоит, предложение не повторяется.

  Запуск: node стенд_шахта-подсказка_181.js <сборка.html>
  Обязан падать на 181.6 и проходить на 181.7.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const kinds = [
  { code:'DM-13', section:'Демонтаж', name:'Демонтаж покрытия потолка', title:'Демонтаж покрытия потолка', unit:'м²', active:true, base_usd:2, volume_base:'потолок' },
  { code:'DM-11', section:'Демонтаж', name:'Демонтаж покрытия пола',    title:'Демонтаж покрытия пола',    unit:'м²', active:true, base_usd:2, volume_base:'пол' }
];
const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд шахты',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[
    { code:'SH', name:'Шахта',  title:'Шахта',  kind:'нежилая', floor_m2:0.81, perimeter_m:3.6, height_m:2.8, wall_m2:8.86,  walls_m2:8.86,  ceiling_m2:0.81 },
    { code:'ZL', name:'Зал',    title:'Зал',    kind:'жилая',   floor_m2:16.39, perimeter_m:16, height_m:2.8, wall_m2:39.66, walls_m2:39.66, ceiling_m2:16.39 },
    { code:'KB', name:'Короб',  title:'Короб',  kind:'нежилая', floor_m2:9.00,  perimeter_m:12, height_m:2.8, wall_m2:33,    walls_m2:33,    ceiling_m2:9.00 },
    /* [181.27] Настоящий туалет 0,75 м² — из «Юнусабада 13». По одной площади
       панель записывала его в полости и снимала пол с потолком вместе с плиткой. */
    { code:'TL', name:'Туалет', title:'Туалет', kind:'санузел', floor_m2:0.75, perimeter_m:3.46, height_m:2.8, wall_m2:9.7,  walls_m2:9.7,  ceiling_m2:0.75 },
    /* Человек сам назвал помещение шахтой — его слово главнее стоп-имени. */
    { code:'ST', name:'Шахта-туалет', title:'Шахта-туалет', kind:'', floor_m2:0.6, perimeter_m:3.1, height_m:2.8, wall_m2:8.7, walls_m2:8.7, ceiling_m2:0.6 }
  ],
  elements:[], adjacency:[], works:[], catalog:{ kinds, price:[
    { code:'DM-13', name:'Демонтаж покрытия потолка', unit:'м²', price_usd:2, active:true },
    { code:'DM-11', name:'Демонтаж покрытия пола',    unit:'м²', price_usd:2, active:true }
  ] }, price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

const разбор = { ok:true, mode:'repair', recognized:'снять покрытия везде',
  rooms:[
    { room:'Шахта', name:'Шахта', code:'SH', kinds:[{code:'DM-13'},{code:'DM-11'}] },
    { room:'Зал',   name:'Зал',   code:'ZL', kinds:[{code:'DM-13'},{code:'DM-11'}] },
    { room:'Короб', name:'Короб', code:'KB', kinds:[{code:'DM-13'},{code:'DM-11'}] }
  ] };

const кусок = (текст, имя) => {
  const i = текст.indexOf(имя);
  if(i < 0) return '';
  const дальше = текст.slice(i + имя.length);
  const j = дальше.search(/\n(Шахта|Зал|Короб)\n/);
  return j >= 0 ? дальше.slice(0, j) : дальше.slice(0, 400);
};

(async () => {
  const порт = 9200 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const из = await page.evaluate((d) => {
    try{ showVRepair(d); }catch(e){ return { нет:e.message }; }
    const л = document.querySelector('.vmask');
    return { текст:(л ? л.innerText : '').slice(0, 3000) };
  }, разбор);
  await page.waitForTimeout(400);
  const текст = из.текст || '';
  const ш = кусок(текст, 'Шахта'), з = кусок(текст, 'Зал'), к = кусок(текст, 'Короб');
  const признак = /Похоже на техническую полость/;

  t('С.1 у помещения меньше 1,5 м² предложение есть', признак.test(ш), (из.нет || ш.slice(0,160)));
  t('С.2 у обычного помещения предложения нет', !признак.test(з), з.slice(0,160));
  t('С.3 имя «Короб» опознаётся при большой площади', признак.test(к), к.slice(0,160));

  const после = await page.evaluate((d) => {
    try{
      if(typeof roomNoFloorSet === 'function') roomNoFloorSet('SH', true);
      else if(typeof roomNoFloorToggle === 'function') roomNoFloorToggle('SH');
      showVRepair(d);
      const л = document.querySelector('.vmask');
      return { текст:(л ? л.innerText : '').slice(0, 3000) };
    }catch(e){ return { нет:e.message }; }
  }, разбор);
  await page.waitForTimeout(400);
  const ш2 = кусок(после.текст || '', 'Шахта');
  t('С.4 когда признак уже стоит, предложение не повторяется',
     !признак.test(ш2), (после.нет || ш2.slice(0,160)));

  const п181 = await page.evaluate(() => ({
    шахта: roomLooksTech('SH'),
    короб: roomLooksTech('KB'),
    зал:   roomLooksTech('ZL'),
    туалет: roomLooksTech('TL'),
    шахтатуалет: roomLooksTech('ST')
  }));
  t('С.7 [181.27] настоящий туалет 0,75 м² полостью НЕ считается',
     п181.туалет === false, JSON.stringify(п181));
  t('С.7-bis «шахта-туалет» остаётся полостью — так назвал человек',
     п181.шахтатуалет === true, JSON.stringify(п181));
  t('С.7-ter регресс: шахта и короб по-прежнему полости, зал — нет',
     п181.шахта === true && п181.короб === true && п181.зал === false, JSON.stringify(п181));

  await br.close(); сервер.close();

  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
