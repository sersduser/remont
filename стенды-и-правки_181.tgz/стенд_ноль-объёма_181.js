/*
  Стенд Д-181-10 — ноль объёма объясняется, а не показывается молча.

  Повод: живой проход 23.08, скрин 1381. Дмитрий отметил «Откосы оконные:
  отделка» и получил «объём: 0 п.м.» Подпись сказала «по контуру проёма: у окна
  периметр, у двери низ не считается» — то есть объяснила МЕРУ, но не ноль.

  Настоящая причина нуля: у вида база «окна:установить», а у единственного окна
  помещения судьба «не трогаем». Работа по нему не планируется — значит и откосов
  нет. Это верный расчёт и невидимая человеку логика: он видит ноль и решает,
  что панель сломалась.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 при судьбе, не подходящей роли, подсказка называет судьбу словами;
    С.2 когда судьба подходит, объём считается и лишней подписи нет;
    С.3 прежний текст меры остался (регресс подсказки 181.1).

  Запуск: node стенд_ноль-объёма_181.js <сборка.html>
  Обязан падать на 181.11 и проходить на 181.12.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const kinds = [
  { code:'OK-06', section:'Окна и остекление', name:'Откосы оконные: отделка',
    title:'Откосы оконные: отделка', unit:'п.м.', active:true, base_usd:4.89, volume_base:'окна:установить', base:'окна:установить' }
];
const комната = (code, name) => ({ code, name, title:name, kind:'жилая', floor_m2:16, perimeter_m:16,
  height_m:2.8, wall_m2:39, walls_m2:39, ceiling_m2:16, windows_cnt:1, doors_cnt:1 });
const окно = (id, код, судьба) => ({ id, name:код + ' ↔ улица', a:код, b:'улица',
  plan:'окно', fact:'окно', fate:судьба, w:2.07, h:1.52 });

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд нуля',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[ комната('SP','Спальня'), комната('ZL','Зал') ],
  elements:[ окно('W1','SP','не трогаем'), окно('W2','ZL','заменить') ],
  adjacency:[], works:[], catalog:{ kinds, price:[{ code:'OK-06', name:'Откосы оконные: отделка', unit:'п.м.', price_usd:4.89, active:true }] },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9800 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const из = await page.evaluate(() => {
    try{
      const k = (D.catalog.kinds || [])[0];
      const sp = (D.rooms || []).find(r => r.code === 'SP');
      const zl = (D.rooms || []).find(r => r.code === 'ZL');
      return {
        подсказкаSP: elemVolHint(k, sp),
        подсказкаZL: elemVolHint(k, zl),
        объёмSP: elemVol(k.code, 'окна', 'установить', '', k.unit),
        объёмZL: elemVol(k.code, 'окна', 'установить', '', k.unit)
      };
    }catch(e){ return { нет:e.message }; }
  });

  t('С.1 подсказка называет судьбу, из-за которой ноль',
     /не трогаем/.test(из.подсказкаSP || ''), (из.нет || из.подсказкаSP || '—'));
  t('С.2 где судьба подходит — лишней подписи нет',
     !/не трогаем/.test(из.подсказкаZL || ''), из.подсказкаZL || '—');
  t('С.3 прежний текст меры остался',
     /по контуру проёма/.test(из.подсказкаSP || '') && /по контуру проёма/.test(из.подсказкаZL || ''),
     (из.подсказкаSP || '') + ' | ' + (из.подсказкаZL || ''));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
