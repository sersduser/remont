/*
  Стенд 181.20 — работа в «комплектах» названа расхождением.

  Повод: живой проход 23.08 по боевому объекту. Тринадцать работ из 127 стоят
  «1 компл» там, где вид меряется метрами, штуками или кубами, — на 400,82 $ из
  3706,68. По такой строке нельзя ни сверить объём, ни применить цену прайса.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 расхождение единицы найдено там, где оно есть;
    С.2 совпадающие единицы молчат;
    С.3 нет каталога или вида — молчим, а не гадаем;
    С.4 оценка объёма считается ОТ ЦЕНЫ ДО распределения (учитывает K);
    С.5 нет ставки в прайсе — расхождение названо, оценка опущена;
    С.6 карточка работы несёт пометку, совпадающая — нет;
    С.7 сводка называет число и деньги;
    С.8 сводки нет, когда расхождений нет;
    С.9 регресс: список работ и фильтры на месте;
    С.10 «п.м.» и «пог.м» считаются одной единицей [181.21];
    С.11 единица в оценке склоняется: 0,4 точки · 7 точек [181.21];
    С.12 оценка меньше единицы объяснена словами [181.21].

  Запуск: node стенд_единица-расходится_181.js <сборка.html>
  Обязан падать на 181.19 и проходить на 181.20.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_20.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const виды = [
  { code:'SN-05', section:'Сантехника', name:'Разводка водоснабжения', unit:'пог.м', base_usd:2.95, active:true },
  { code:'ML-22', section:'Малярка',    name:'Стены: покраска',        unit:'м²',    base_usd:1.50, active:true },
  { code:'UB-01', section:'Уборка',     name:'Вывоз мусора',           unit:'м³',    base_usd:9.42, active:true },
  { code:'ZZ-99', section:'Прочее',     name:'Без цены в прайсе',      unit:'шт',    base_usd:5.00, active:true },
  { code:'OT-02', section:'Отопление',  name:'Разводка отопления',     unit:'точка', base_usd:24.81, active:true },
  { code:'OK-06', section:'Окна',       name:'Откосы оконные',         unit:'п.м.',  base_usd:4.89,  active:true }
];
const прайс = [
  { who:'Ю', code:'SN-05', name:'Разводка водоснабжения', unit:'пог.м', price_usd:2.95, active:true },
  { who:'Ю', code:'ML-22', name:'Стены: покраска',        unit:'м²',    price_usd:1.50, active:true },
  { who:'Ю', code:'UB-01', name:'Вывоз мусора',           unit:'м³',    price_usd:9.42, active:true },
  { who:'Ю', code:'ZZ-99', name:'Без цены в прайсе',      unit:'шт',    price_usd:null, active:true },
  { who:'Ю', code:'OT-02', name:'Разводка отопления',     unit:'точка', price_usd:24.81, active:true },
  /* Та же единица другой записью: прайс «пог.м», справочник «п.м.» — сверка
     обязана считать это ОДНОЙ единицей, а не расхождением [181.21]. */
  { who:'Ю', code:'OK-06', name:'Откосы оконные',         unit:'пог.м', price_usd:4.89,  active:true }
];
/* Боевая форма: связь с помещением по имени, вид словами в примечании.
   K = 0,954358 — коэффициент договора этого объекта; 95,44 / K / 2,95 = 33,9. */
const работы = [
  { code:'VN-14', room:'Ванная (пом. 3)', section:'Сантехника', name:'Разводка водоснабжения', unit:'компл', qty:1,  status:'Не начато', note:'вид SN-05', price_alloc_usd:95.44 },
  { code:'ZL-02', room:'Зал (пом. 5)',    section:'Малярка',    name:'Стены: покраска',        unit:'м²',    qty:34, status:'Не начато', note:'вид ML-22', price_alloc_usd:48.67 },
  { code:'OB-01', room:'Общие',           section:'Уборка',     name:'Вывоз мусора',           unit:'компл', qty:1,  status:'Не начато', note:'вид UB-01', price_alloc_usd:0 },
  { code:'ZZ-01', room:'Зал (пом. 5)',    section:'Прочее',     name:'Без цены в прайсе',      unit:'компл', qty:1,  status:'Не начато', note:'вид ZZ-99', price_alloc_usd:20 },
  { code:'NN-01', room:'Зал (пом. 5)',    section:'Прочее',     name:'Без вида в примечании',  unit:'компл', qty:1,  status:'Не начато', note:'',          price_alloc_usd:10 },
  { code:'SP-10', room:'Зал (пом. 5)',    section:'Отопление',  name:'Разводка отопления',     unit:'компл', qty:1,  status:'Не начато', note:'вид OT-02', price_alloc_usd:9.54 },
  { code:'OK-01', room:'Зал (пом. 5)',    section:'Окна',       name:'Откосы оконные',         unit:'пог.м', qty:6,  status:'Не начато', note:'вид OK-06', price_alloc_usd:28.63 }
];

const данные = (cat) => ({ ok:true, role:'admin', kind:'admin', title:'Стенд единиц',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал (пом. 5)', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 },
         { code:'VN', name:'Ванная (пом. 3)', kind:'санузел', floor_m2:4, perimeter_m:9, height_m:2.8, wall_m2:23, ceiling_m2:4 }],
  elements:[], adjacency:[], works: работы, catalog: cat, price: прайс, access:[], modifiers:[],
  docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{ 'Коэффициент_K': 0.954358, 'Договор_USD': 3700 },
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9100 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json',
                    body: JSON.stringify(данные({ kinds: виды, price: прайс })) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1400);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof workUnitNote === 'function' && typeof workUnitGapList === 'function');
  t('функции workUnitNote и workUnitGapList существуют', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const р = await page.evaluate(async () => {
    if(!D.catalog) { try{ await loadCatalog(); }catch(e){} }
    const по = c => (D.works || []).find(w => w.code === c);
    return {
      VN14: workUnitNote(по('VN-14')),
      ZL02: workUnitNote(по('ZL-02')),
      OB01: workUnitNote(по('OB-01')),
      ZZ01: workUnitNote(по('ZZ-01')),
      NN01: workUnitNote(по('NN-01')),
      список: workUnitGapList().map(w => w.code)
    };
  });
  t('С.1 расхождение найдено у VN-14', /единица расходится/.test(р.VN14) && /пог\.м/.test(р.VN14), р.VN14);
  t('С.2 совпадающая единица молчит', р.ZL02 === '', р.ZL02);
  t('С.3 без вида в примечании молчим', р.NN01 === '', р.NN01);
  /* 95,44 / 0,954358 = 100,00 → / 2,95 = 33,9 пог.м. Объёмы от десяти и выше
     округляются до целого — «около 34» честнее ложной точности «33,9». */
  t('С.4 оценка объёма учитывает K: 95,44 / 0,954358 / 2,95 → около 34',
     /около 34 пог\.м/.test(р.VN14), р.VN14);
  t('С.5 нет ставки — расхождение названо, оценки нет',
     /единица расходится/.test(р.ZZ01) && !/около/.test(р.ZZ01), р.ZZ01);
  t('С.5-bis нулевая цена — оценки нет', /единица расходится/.test(р.OB01) && !/около/.test(р.OB01), р.OB01);
  /* Три: VN-14 · OB-01 · ZZ-01. ZL-02 единицу не расходит, NN-01 без вида —
     сравнивать не с чем, и панель молчит, а не гадает. */
  /* Четыре: VN-14 · OB-01 · ZZ-01 · SP-10. Не входят: ZL-02 (единицы совпали),
     NN-01 (вида нет — сравнивать не с чем), OK-01 («п.м.» и «пог.м» — одна
     единица, приведённая unitNorm). */
  t('С.1-bis список расхождений — четыре строки, без ZL-02, NN-01 и OK-01',
     р.список.length === 4 && р.список.indexOf('ZL-02') < 0 &&
     р.список.indexOf('NN-01') < 0 && р.список.indexOf('OK-01') < 0,
     JSON.stringify(р.список));

  /* Стенд обязан говорить «функции нет», а не падать с исключением: упавший
     стенд неотличим от сломанного стенда [181.21]. */
  const естьЯзык = await page.evaluate(() => typeof unitNorm === 'function' && typeof unitForm === 'function');
  t('функции unitNorm и unitForm существуют', естьЯзык);
  const язык = !естьЯзык ? { SP10:'', OK01:'(нет функций)', норм:[], формы:[] } : await page.evaluate(() => {
    const по = c => (D.works || []).find(w => w.code === c);
    return {
      SP10: workUnitNote(по('SP-10')),
      OK01: workUnitNote(по('OK-01')),
      норм: [unitNorm('п.м.'), unitNorm('пог.м'), unitNorm('м2'), unitNorm('М²')],
      формы: [unitForm('точка', 1), unitForm('точка', 0.4), unitForm('точка', 3), unitForm('точка', 7), unitForm('шт', 5)]
    };
  });
  t('С.10 «п.м.» и «пог.м» — одна единица, расхождения нет',
     язык.OK01 === '', 'вернулось: ' + язык.OK01);
  t('С.10-bis unitNorm приводит записи к одной',
     язык.норм[0] === 'пог.м' && язык.норм[1] === 'пог.м' && язык.норм[2] === 'м²' && язык.норм[3] === 'м²',
     JSON.stringify(язык.норм));
  t('С.11 склонение единицы: точка · точки · точки · точек · шт',
     язык.формы[0] === 'точка' && язык.формы[1] === 'точки' && язык.формы[2] === 'точки' &&
     язык.формы[3] === 'точек' && язык.формы[4] === 'шт', JSON.stringify(язык.формы));
  t('С.11-bis в оценке единица склонена', /около 0,4 точки/.test(язык.SP10), язык.SP10);
  t('С.12 оценка меньше единицы объяснена словами',
     /меньше одной единицы/.test(язык.SP10), язык.SP10);

  const h = await page.evaluate(() => SCREENS.works());
  t('С.6 карточка несёт пометку', /⚠ единица расходится/.test(h), (h.match(/единица расходится[^<]{0,70}/) || [''])[0]);
  t('С.7 сводка называет число и деньги',
     /4 работы стоят в комплектах/.test(h) && /на 125 \$/.test(h),
     (h.match(/работ[аы]? сто[ия]т[^<]{0,120}/) || [''])[0]);
  t('С.9 регресс: фильтры и список на месте',
     /Скрыть готовое/.test(h) && /Разводка водоснабжения/.test(h), 'разметка неполна');

  const пусто = await page.evaluate(() => {
    const было = D.works;
    D.works = было.filter(w => w.code === 'ZL-02');
    const h = SCREENS.works();
    D.works = было;
    return h;
  });
  t('С.8 без расхождений сводки нет', !/в комплектах вместо своей единицы/.test(пусто), 'сводка показана зря');

  console.log('\n=== 181.20 · единица расходится ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
