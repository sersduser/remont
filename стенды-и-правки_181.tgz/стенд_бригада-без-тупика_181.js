/*
  Стенд 181.22 — отсылка «выберите в списке» ведёт туда, куда роли есть ход.

  Повод: живой проход 23.08. Экран «Имя бригады» без выбранной бригады советовал
  «вернитесь и выберите её в списке "Мои бригады"». Блок «Мои бригады» живёт на
  бригадирском виде (crewSide = kind hand|foreman); у Дмитрия на его объекте
  kind = admin, и этого блока он не видит вовсе — совет вёл в тупик.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 бригадиру: названо, где список, и дана кнопка туда;
    С.2 администратору: сказано, что отсюда бригаду не выбрать, и почему;
    С.3 администратору не обещают список, которого он не увидит;
    С.4 роль названа своим словом (администратор / заказчик);
    С.5 то же на экране передачи бригады;
    С.6 регресс: при выбранной бригаде экран прежний, поле имени на месте.

  Запуск: node стенд_бригада-без-тупика_181.js <сборка.html>
  Обязан падать на 181.21 и проходить на 181.22.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_22.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const данные = (kind) => ({ ok:true, role: kind === 'foreman' ? 'foreman' : 'admin', kind: kind,
  title:'Стенд бригады', object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест',
  object_verified:true, objectVia:'key', rooms:[], elements:[], adjacency:[], works:[],
  catalog:{ kinds:[], price:[] }, price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[],
  payments:[], changes:[], settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9200 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(данные('admin')) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof crewNoPick === 'function');
  t('функция crewNoPick существует', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const адм = await page.evaluate(() => {
    D.kind = 'admin'; CREW_PICK = ''; CREWS = [];
    return { имя: crewNameScreen(), передача: crewGiveScreen(), текст: crewNoPick() };
  });
  t('С.2 администратору сказано, что отсюда не выбрать',
     /отсюда её не выбрать/.test(адм.текст) && /бригадирскому виду/.test(адм.текст), адм.текст.slice(0, 200));
  t('С.3 администратору не обещают открыть список',
     !/Открыть список бригад/.test(адм.текст), 'обещана кнопка списка');
  t('С.4 роль названа словом «администратор»', /как администратор/.test(адм.текст), адм.текст.slice(0,200));
  t('С.2-bis экран имени несёт это объяснение', /отсюда её не выбрать/.test(адм.имя), 'экран имени молчит');
  t('С.5 экран передачи несёт то же', /отсюда её не выбрать/.test(адм.передача), 'экран передачи молчит');
  t('С.5-bis старого совета «Вернитесь и выберите» больше нет',
     !/Вернитесь и выберите/.test(адм.имя) && !/Вернитесь и выберите/.test(адм.передача), 'старый текст остался');

  const зак = await page.evaluate(() => { D.kind = 'owner'; return crewNoPick(); });
  t('С.4-bis заказчику — своё слово', /как заказчик/.test(зак), зак.slice(0,160));

  const бриг = await page.evaluate(() => { D.kind = 'foreman'; return crewNoPick(); });
  t('С.1 бригадиру названо место списка',
     /Список бригад — на экране «Бригада»/.test(бриг) && /Сделать текущей/.test(бриг), бриг.slice(0,200));
  t('С.1-bis бригадиру дана кнопка туда', /Открыть список бригад/.test(бриг), 'кнопки нет');

  const свыбором = await page.evaluate(() => {
    D.kind = 'foreman';
    CREWS = [{ crew:'c1', name:'Бригада Юрия', members:3, created:'2026-08-01' }];
    CREW_PICK = 'c1';
    return crewNameScreen();
  });
  t('С.6 регресс: при выбранной бригаде экран прежний',
     /Впишите новое название/.test(свыбором) && /cwr_name/.test(свыбором) && !/отсюда её не выбрать/.test(свыбором),
     свыбором.slice(0, 160));

  console.log('\n=== 181.22 · бригада без тупика ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
