# -*- coding: utf-8 -*-
"""Чат 181 · Д-181-22: экран «Мои деньги» падает у работника, когда сервер
не прислал его блок денег.

Найдено прогоном всех экранов по ролям 23.08: `hand/money` даёт исключение
`Cannot read properties of undefined (reading 'received_usd')`. Экран не просто
пустеет — он рушится, и человек видит белое поле вместо денег.

Причина в одной строке: `const m = D.my_money;` и сразу `m.received_usd`, без
проверки. Блока `my_money` в ответе может не быть — у нового работника, при
отказе ветки, при неполном ответе сервера.

Правило, которое здесь нарушено, в панели уже записано — в комментарии к
`home()`: «Экран, который читает D, обязан переживать его отсутствие». Тот же
`home()` защищён (`worker && m ? …`), а `money()` — нет.

Правка: `m` перестаёт быть обязательным, а отсутствие блока названо словами и
отделено от нуля. «Получено 0 $» и «сервер не прислал ваши деньги» — разные
сообщения, и путать их нельзя: первое говорит «вам не платили», второе —
«я не знаю, платили ли вам».
"""
import io, sys

ФАЙЛ = sys.argv[1] if len(sys.argv) > 1 else '/tmp/panel_181_30.html'
т = io.open(ФАЙЛ, encoding='utf-8').read()
было = len(т.encode('utf-8'))

def замена(старое, новое, имя):
    global т
    n = т.count(старое)
    assert n == 1, f'{имя}: вхождений {n}, а нужно ровно 1'
    т = т.replace(старое, новое, 1)
    print(f'  ✓ {имя}')

замена(
"""  if(D.role === "worker"){
    const m = D.my_money;
    return `
      <div class="hello">Мои деньги</div>
      <div class="sub">на ${new Date().toLocaleDateString("ru-RU")}</div>

      <div class="card">
        <div class="lbl">За работу</div>
        <div class="li"><div class="n">Договор${dealDelta() ? `<div class="d">${esc(dealNote())}</div>` : ""}</div><div class="v">${usd(dealSum())} $</div></div>
        <div class="li"><div class="n">Получено</div><div class="v ok" style="color:var(--ok)">${fmt(m.received_usd)} $</div></div>""",
"""  if(D.role === "worker"){
    /* [181, Д-181-22] Блока `my_money` в ответе может не быть — у нового
       работника, при отказе ветки, при неполном ответе. Раньше экран падал на
       первом же обращении к полю и человек видел белое поле вместо денег.
       Отсутствие блока — не ноль: «получено 0» значит «вам не платили»,
       а «сервер не прислал» значит «я не знаю, платили ли вам». */
    const m = D.my_money || {};
    const немДеньги = !D.my_money;
    return `
      <div class="hello">Мои деньги</div>
      <div class="sub">на ${new Date().toLocaleDateString("ru-RU")}</div>
      ${немДеньги ? `<div class="stat"><span class="k">Сервер не прислал ваши выплаты — показать, сколько получено, нечем. Остальные числа на экране посчитаны из сметы и приёмки, они верны. Обновите экран; если строка останется, скажите бригадиру: выплаты заводит он.</span></div>` : ""}

      <div class="card">
        <div class="lbl">За работу</div>
        <div class="li"><div class="n">Договор${dealDelta() ? `<div class="d">${esc(dealNote())}</div>` : ""}</div><div class="v">${usd(dealSum())} $</div></div>
        <div class="li"><div class="n">Получено</div><div class="v ok" style="color:var(--ok)">${немДеньги ? "—" : fmt(m.received_usd) + " $"}</div></div>""",
'экран денег работника переживает отсутствие блока')

n = т.count('const BUILD = "181.29"')
assert n == 1, f'версия: вхождений {n}'
т = т.replace('const BUILD = "181.29"', 'const BUILD = "181.30"', 1)
print('  ✓ версия → 181.30')

io.open(ФАЙЛ, 'w', encoding='utf-8').write(т)
стало = len(т.encode('utf-8'))
print(f'\n{ФАЙЛ}: {было} → {стало} б (+{стало-было})')
