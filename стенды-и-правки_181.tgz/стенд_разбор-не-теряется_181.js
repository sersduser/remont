/*
  Стенд Д-181-4 — разбор голоса переживает выход из окна.

  Повод: живой проход 23.08 ночью, слова Дмитрия: «Вышел из этого окна и
  вернуться невозможно — подтвердить данные не могу». Разбор голоса живёт
  только в памяти вкладки: closeVSheet() стирает его, и вся наговорённая
  работа пропадает. Дороже этого в проходе ничего не было.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 окно разбора открылось и показало строки;
    С.2 разбор сохранён — переживёт выход;
    С.3 после закрытия окна сохранённое на месте;
    С.4 есть ход возврата, и он открывает то же окно с теми же строками;
    С.5 сохранённое привязано к объекту (ключ несёт хвост ключа доступа);
    С.6 разбор старше суток не предлагается.

  Запуск: node стенд_разбор-не-теряется_181.js <сборка.html>
  Обязан падать на 181.5 и проходить на 181.6.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const kinds = [
  { code:'ML-16', section:'Малярка', name:'Стены: оклейка обоями', title:'Стены: оклейка обоями', unit:'м²', active:true, base_usd:1.5, volume_base:'стены' },
  { code:'ML-12', section:'Малярка', name:'Потолок: покраска',     title:'Потолок: покраска',     unit:'м²', active:true, base_usd:1.5, volume_base:'потолок' }
];
const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд разбора',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал', title:'Зал', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, walls_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works:[], catalog:{ kinds, price:[
    { code:'ML-16', name:'Стены: оклейка обоями', unit:'м²', price_usd:1.5, active:true },
    { code:'ML-12', name:'Потолок: покраска',     unit:'м²', price_usd:1.5, active:true }
  ] }, price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

/* Разбор в той форме, в какой его отдаёт ветка голоса. */
const разбор = {
  ok:true, mode:'repair', recognized:'в зале стены обои, потолок покраска',
  rooms:[ { room:'Зал', code:'ZL', kinds:[ { code:'ML-16' }, { code:'ML-12' } ] } ]
};

(async () => {
  const порт = 8900 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const открыт = await page.evaluate((d) => {
    try{
      if(typeof showVRepair !== 'function') return { нет:'нет showVRepair' };
      showVRepair(d);
      const л = document.querySelector('.vmask');
      return { текст:(л ? л.innerText : document.body.innerText || '').slice(0, 900) };
    }catch(e){ return { нет:e.message }; }
  }, разбор);
  await page.waitForTimeout(400);
  t('С.1 окно разбора открылось и показало строки',
     /Работы по помещениям/.test(открыт.текст || '') && /ML-16/.test(открыт.текст || ''),
     (открыт.нет || (открыт.текст || '').slice(0,140)));

  const сохр = await page.evaluate(() => {
    const из = {};
    for(let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if(/VOICE|РАЗБОР/i.test(k)) из[k] = String(localStorage.getItem(k)).slice(0, 200);
    }
    return { ключи:Object.keys(из), первый:Object.values(из)[0] || '' };
  });
  t('С.2 разбор сохранён — переживёт выход',
     сохр.ключи.length > 0 && /ML-16|recognized/i.test(сохр.первый),
     'ключей: ' + JSON.stringify(сохр.ключи));
  t('С.5 сохранённое привязано к объекту',
     сохр.ключи.some(k => k.indexOf(KEY.slice(-12)) >= 0), 'ключи: ' + JSON.stringify(сохр.ключи));

  const после = await page.evaluate(() => {
    try{ if(typeof closeVSheet === 'function') closeVSheet(); }catch(e){}
    const есть = [];
    for(let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); if(/VOICE/i.test(k)) есть.push(k); }
    return { ключей: есть.length, естьВозврат: typeof voiceRestore === 'function', естьЧтение: typeof voiceKept === 'function' };
  });
  t('С.3 после закрытия окна сохранённое на месте', после.ключей > 0, JSON.stringify(после));

  const возврат = await page.evaluate(() => {
    try{
      if(typeof voiceRestore !== 'function') return { нет:'нет voiceRestore' };
      voiceRestore();
      const л = document.querySelector('.vmask');
      return { текст:(л ? л.innerText : document.body.innerText || '').slice(0, 900) };
    }catch(e){ return { нет:e.message }; }
  });
  await page.waitForTimeout(400);
  t('С.4 ход возврата открывает то же окно с теми же строками',
     /Работы по помещениям/.test(возврат.текст || '') && /ML-16/.test(возврат.текст || ''),
     (возврат.нет || (возврат.текст || '').slice(0,140)));

  const стар = await page.evaluate(() => {
    try{
      if(typeof voiceKept !== 'function') return 'нет voiceKept';
      for(let i = 0; i < localStorage.length; i++){
        const k = localStorage.key(i);
        if(/VOICE/i.test(k)){
          const v = JSON.parse(localStorage.getItem(k));
          v.at = Date.now() - 30 * 60 * 60 * 1000;      // 30 часов назад
          localStorage.setItem(k, JSON.stringify(v));
        }
      }
      return voiceKept() ? 'предлагает' : 'молчит';
    }catch(e){ return 'ошибка: ' + e.message; }
  });
  t('С.6 разбор старше суток не предлагается', стар === 'молчит', String(стар));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
