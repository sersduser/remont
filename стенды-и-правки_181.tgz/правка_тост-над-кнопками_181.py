# -*- coding: utf-8 -*-
"""Панель: подсказка (тост) перестаёт закрывать кнопки нижнего окна.

Дефект Д-181-1, пойман живым проходом Дмитрия 22.08 (скрины 1306→1308).
Последовательность: в окне «Обмеры помещений» он нажал «Записать отмеченное»
до того, как отметил строку → всплыла подсказка «Ничего не отмечено —
коснитесь строки, чтобы отметить» → подсказка легла ПОВЕРХ кнопок окна
(`.toast` прибит к низу экрана, `bottom:18px`, `z-index:10000`) и висит
25 секунд (`TOAST_WAIT_MS`). Он сделал ровно то, что подсказка велела —
коснулся строки, она отметилась, — а кнопки записи не увидел: она их закрыла.

Лечение: при открытом нижнем окне подсказка показывается СВЕРХУ, а не снизу.
Кнопки остаются видны, смысл подсказки не теряется.

Идемпотентна. Запуск: python3 правка_тост-над-кнопками_181.py <файл.html>
"""
import hashlib, sys
from pathlib import Path

МАРКЕР = "toast up"

CSS_ИЗ = ".toast.on{opacity:1;transform:none;pointer-events:auto;cursor:pointer}"
CSS_В = """.toast.on{opacity:1;transform:none;pointer-events:auto;cursor:pointer}

/* [181, Д-181-1] Подсказка не должна закрывать кнопки нижнего окна: при
   открытом окне она уезжает наверх. Повод — живой проход 22.08: подсказка
   «коснитесь строки, чтобы отметить» легла на кнопку «Записать отмеченное»
   и провисела 25 секунд, то есть помешала выполнить то, что сама советует. */
.toast.up{top:14px;bottom:auto;transform:translateY(-12px)}
.toast.up.on{transform:none}"""

JS_ИЗ = """  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast on" + (kind ? " " + kind : "");"""
JS_В = """  const t = document.getElementById("toast");
  t.textContent = msg;
  /* [181, Д-181-1] Открыто нижнее окно — подсказку наверх, иначе она закроет
     кнопки этого окна (у нижнего листа они внизу, у подсказки — тоже). */
  const наЛисте = (function(){ try{ return !!(vmask && vmask.classList.contains("on")); }catch(e){ return false; } })();
  t.className = "toast on" + (kind ? " " + kind : "") + (наЛисте ? " up" : "");"""

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    ф = Path(sys.argv[1]); исходный = ф.read_text(encoding="utf-8")
    if МАРКЕР in исходный:
        print("уже применено:", ф.name); return 0
    беды = []; т = исходный
    if CSS_ИЗ not in т: беды.append("якорь CSS")
    else: т = т.replace(CSS_ИЗ, CSS_В, 1)
    if JS_ИЗ not in т: беды.append("якорь функции toast")
    else: т = т.replace(JS_ИЗ, JS_В, 1)
    if беды:
        print("ОТКАЗ, файл не тронут: нет —", ", ".join(беды)); return 3
    ф.write_text(т, encoding="utf-8")
    print("до :", len(исходный.encode()), "б  sha16", hashlib.sha256(исходный.encode()).hexdigest()[:16])
    print("после:", len(т.encode()), "б  sha16", hashlib.sha256(т.encode()).hexdigest()[:16])
    return 0

sys.exit(main())
