/*
  Стенд 181.24 — срок на главном экране не меняет знак сам собой.

  Повод: живой проход 23.08. Главный экран при входе — «Отставание от графика
  2,4 дн», экран «Сроки» следом — «Опережение 0,3 дн». Считает одна и та же
  timeCalc(); разница в том, что технологические паузы (`pause_days`) живут в
  справочнике, а справочник грузится по требованию. Без него паузы = 0, срок
  41,5 вместо 42,8, и знак расхождения переворачивается.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 без справочника паузы не учтены — число ПОМЕЧЕНО предварительным;
    С.2 предварительное отставание не красится тревожным цветом;
    С.3 подпись говорит, что справочник ещё грузится;
    С.4 со справочником пометки нет, подпись прежняя;
    С.5 со справочником паузы учтены и число меняется (знак может смениться);
    С.6 главный экран сам просит справочник (флаг однократности взведён);
    С.7 регресс: остальные меры главного экрана на месте.

  Запуск: node стенд_срок-с-паузами_181.js <сборка.html>
  Обязан падать на 181.23 и проходить на 181.24.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_24.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

/* Пауза в 7 дней у вида стяжки — ровно тот случай, из-за которого срок
   объекта на боевых данных вырос с 41,5 до 42,8 дня. */
const виды = [
  { code:'PL-05', section:'Полы',    name:'Стяжка',          unit:'м²', base_usd:5, active:true, pause: 7 },
  { code:'ML-22', section:'Малярка', name:'Стены: покраска', unit:'м²', base_usd:2, active:true, pause: null }
];
const работы = [
  { code:'ZL-01', room:'Зал (пом. 5)', section:'Полы',    name:'Стяжка',          unit:'м²', qty:16, status:'Готово',    progress:100, dur:2, note:'вид PL-05', price_alloc_usd:80, updated:'2026-08-01' },
  { code:'ZL-02', room:'Зал (пом. 5)', section:'Малярка', name:'Стены: покраска', unit:'м²', qty:40, status:'Не начато', progress:0,   dur:3, note:'вид ML-22', price_alloc_usd:80, deps:'ZL-01' }
];
const данные = () => ({ ok:true, role:'admin', kind:'admin', title:'Стенд срока',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал (пом. 5)', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works: работы, catalog: null, price:[], access:[], modifiers:[],
  docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{ 'Договор_USD': 200, 'Оплачено_за_работу_USD': 100, 'Дата_начала_работ': '2026-07-24' },
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9500 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json',
                    body: JSON.stringify(Object.assign(данные(), { catalog:{ kinds: виды, price: [] } })) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1400);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof timeReady === 'function');
  t('функция timeReady существует', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const без = await page.evaluate(() => {
    const было = D.catalog; D.catalog = null;
    const r = { готов: timeReady(), подпись: timeNote(), экран: SCREENS.home(), расчёт: timeCalc() };
    D.catalog = было; return r;
  });
  t('С.1 без справочника число помечено предварительным',
     без.готов === false && /\(предварительно\)/.test(без.экран), 'пометки нет');
  t('С.2 предварительное число не красится тревогой',
     !/#ff9f0a/.test((без.экран.match(/Опережение графика|Отставание от графика[\s\S]{0,240}/) || [''])[0]),
     'тревожный цвет включён на предварительном числе');
  t('С.3 подпись говорит про справочник',
     /справочник ещё грузится/.test(без.подпись), без.подпись);
  t('С.3-bis паузы без справочника нулевые', без.расчёт.pauses === 0, 'pauses=' + без.расчёт.pauses);

  const с = await page.evaluate(() => ({
    готов: timeReady(), подпись: timeNote(), экран: SCREENS.home(), расчёт: timeCalc()
  }));
  t('С.4 со справочником пометки нет', с.готов === true && !/\(предварительно\)/.test(с.экран), 'пометка осталась');
  t('С.4-bis подпись прежняя', /по календарю плана/.test(с.подпись), с.подпись);
  t('С.5 со справочником паузы учтены', с.расчёт.pauses > 0, 'pauses=' + с.расчёт.pauses);
  t('С.5-bis срок со справочником длиннее', с.расчёт.real > без.расчёт.real,
     без.расчёт.real + ' → ' + с.расчёт.real);

  const флаг = await page.evaluate(() => {
    HOME_CAT_TRY = false; const было = D.catalog; D.catalog = null;
    SCREENS.home();
    const f = HOME_CAT_TRY; D.catalog = было; return f;
  });
  t('С.6 главный экран сам просит справочник', флаг === true, 'флаг не взведён');

  t('С.7 регресс: остальные меры на месте',
     /Готовность|Цена объекта|Отработано аванса/.test(с.экран), 'меры пропали');

  console.log('\n=== 181.24 · срок с паузами ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
