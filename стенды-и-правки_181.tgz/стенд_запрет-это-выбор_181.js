/*
  Стенд 181.16 — «запрещено» это выбор бригадира, а не мусор слоя.

  Повод: живой проход по боевому прайсу Юрия 23.08. Шапка говорила «запрещено 83»
  и показывала 83 карточки, тогда как настоящих запретов — ноль: 69 строк
  относятся к снятым видам, 14 дублируют активные. Вторым тем же экраном:
  «Задано 99 из 99 · всё заполнено» при 55 видах, которых в прайсе нет вовсе.

  Что меряется:
    С.0  страница поднялась без ошибок JS;
    С.1  «запрещено N» считает только выбор бригадира;
    С.2  блок «Запрещено для себя» показывает только его же;
    С.3  служебные строки названы числом и причинами, карточками не показаны;
    С.4  кнопка разворачивает служебные строки;
    С.5  пробел прайса назван числом в шапке и в блоке;
    С.6  виды без ставки рынка названы отдельной цифрой (со склонением, 181.17);
    С.7  нет настоящих запретов → блока «Запрещено для себя» нет вовсе;
    С.8  каталог не загружен → сказано «справочник ещё не загрузился», а не «нет позиций»;
    С.9  регресс: активные строки на месте, отклонение цены считается.

  Запуск: node стенд_запрет-это-выбор_181.js <сборка.html>
  Обязан падать на 181.15 и проходить на 181.16.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_16.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

// справочник: 6 активных видов + 2 снятых
const виды = [
  { code:'ML-01', name:'Малярка стен',   section:'Малярка', unit:'м²', base_usd:3,  active:true },
  { code:'ML-02', name:'Малярка потолка',section:'Малярка', unit:'м²', base_usd:3.2,active:true },
  { code:'ML-03', name:'Грунтовка',      section:'Малярка', unit:'м²', base_usd:1,  active:true },
  { code:'KF-01', name:'Кафель пол',     section:'Кафель',  unit:'м²', base_usd:8,  active:true },
  { code:'KF-02', name:'Кафель стены',   section:'Кафель',  unit:'м²', base_usd:9,  active:true },
  { code:'PR-01', name:'Обмерный план',  section:'Проект',  unit:'компл', base_usd:0, active:true },  // без ставки рынка
  { code:'OLD-1', name:'Старый вид 1',   section:'Прочее',  unit:'шт', base_usd:5,  active:false },   // снят
  { code:'OLD-2', name:'Старый вид 2',   section:'Прочее',  unit:'шт', base_usd:5,  active:false }
];
// прайс: 2 активные · 1 настоящий запрет · 2 мусорных (снятый вид) · 1 дубль-близнец
const прайс = [
  { who:'Юрий', code:'ML-01', name:'Малярка стен',   unit:'м²', price_usd:4.60, active:true  },
  { who:'Юрий', code:'ML-02', name:'Малярка потолка',unit:'м²', price_usd:3.50, active:true  },
  { who:'Юрий', code:'ML-03', name:'Грунтовка',      unit:'м²', price_usd:1.20, active:false }, // ← НАСТОЯЩИЙ запрет
  { who:'Юрий', code:'OLD-1', name:'Старый вид 1',   unit:'шт', price_usd:5.00, active:false }, // мусор: вид снят
  { who:'Юрий', code:'OLD-2', name:'Старый вид 2',   unit:'шт', price_usd:5.00, active:false }, // мусор: вид снят
  { who:'Юрий', code:'ML-01', name:'Малярка стен',   unit:'м²', price_usd:4.60, active:false }  // мусор: близнец активен
];
// в прайсе нет: KF-01, KF-02 (со ставкой) и PR-01 (без ставки)

const данные = (cat) => ({ ok:true, role:'crew', kind:'crew', title:'Стенд запретов',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Бригадир', object_verified:true, objectVia:'key',
  rooms:[], elements:[], adjacency:[], works:[], catalog: cat, price: (cat && cat.price) || [],
  access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 8800 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json',
                    body: JSON.stringify(данные({ kinds: виды, price: прайс })) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof bookOffSplit === 'function' && typeof bookGap === 'function');
  t('функции bookOffSplit и bookGap существуют', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const р = await page.evaluate(() => {
    const s = bookOffSplit(), g = bookGap();
    return { свой: s.свой.map(p=>p.code), служ: s.служебные.map(p=>p.code), почему: s.почему,
             gapЦена: g.сЦеной.map(k=>k.code), gapБез: g.безЦены.map(k=>k.code) };
  });
  t('С.1 настоящий запрет ровно один — ML-03',
     р.свой.length === 1 && р.свой[0] === 'ML-03', JSON.stringify(р.свой));
  t('С.1 служебных строк три', р.служ.length === 3, JSON.stringify(р.служ));
  t('С.1 причины названы обе', Object.keys(р.почему).length === 2, JSON.stringify(р.почему));
  t('С.5 пробел со ставкой — KF-01 и KF-02',
     р.gapЦена.length === 2 && р.gapЦена.includes('KF-01') && р.gapЦена.includes('KF-02'), JSON.stringify(р.gapЦена));
  t('С.6 пробел без ставки — PR-01',
     р.gapБез.length === 1 && р.gapБез[0] === 'PR-01', JSON.stringify(р.gapБез));

  const h = await page.evaluate(() => SCREENS.book());
  t('С.1 шапка: «запрещено 1», а не 4', /запрещено 1(?!\d)/.test(h) && !/запрещено 4/.test(h),
     (h.match(/Задано[^<]*/) || [''])[0]);
  t('С.5 шапка называет пробел: «нет в прайсе 2»', /нет в прайсе 2(?!\d)/.test(h),
     (h.match(/Задано[^<]*/) || [''])[0]);
  t('С.2 блок «Запрещено для себя» есть и говорит (1)', /Запрещено для себя \(1\)/.test(h),
     (h.match(/Запрещено для себя[^<]*/) || [''])[0]);
  t('С.3 служебные названы числом и причиной',
     /Ещё 3 строк(и|) прайса относятся/.test(h) && /вид снят из справочника — 2/.test(h) && /код уже есть в прайсе живой строкой — 1/.test(h),
     (h.match(/Ещё 3[^<]*/) || [''])[0]);
  t('С.5 блок пробела объясняет последствие',
     /2<\/b> вида справочника не заведены/.test(h) && /смета возьмёт ориентир рынка/.test(h),
     (h.match(/видов справочника[^<]*/) || [''])[0]);
  t('С.6 виды без ставки названы отдельно', /Ещё 1 вид рынок отдельно не оценивает/.test(h),
     (h.match(/рынок отдельно[^<]*/) || [''])[0]);

  /* Без \b: имя вида кончается цифрой («Старый вид 1OLD-1»), и граница слова
     между «1» и «O» не срабатывает — приём 383 в новой форме. */
  const карточки = await page.evaluate(() => {
    const d = document.createElement('div'); d.innerHTML = SCREENS.book();
    const коды = [...d.querySelectorAll('.work')].map(x => (x.textContent.match(/(ML|KF|OLD|PR)-\d+/) || [''])[0]);
    return коды;
  });
  t('С.2 карточки: два активных вида и один запрет',
     карточки.filter(c=>c==='ML-01').length === 1 && карточки.includes('ML-02') && карточки.includes('ML-03'),
     JSON.stringify(карточки));
  t('С.3 мусорные строки карточками не показаны',
     !карточки.includes('OLD-1') && !карточки.includes('OLD-2'), JSON.stringify(карточки));

  const развёрнут = await page.evaluate(() => {
    bookSvcToggle();
    const d = document.createElement('div'); d.innerHTML = SCREENS.book();
    const коды = [...d.querySelectorAll('.work')].map(x => (x.textContent.match(/(ML|KF|OLD|PR)-\d+/) || [''])[0]);
    bookSvcToggle();
    return коды;
  });
  t('С.4 кнопка разворачивает служебные строки',
     развёрнут.includes('OLD-1') && развёрнут.includes('OLD-2'), JSON.stringify(развёрнут));

  t('С.9 регресс: отклонение цены на месте',
     /▲|▼/.test(h), 'стрелок в экране нет');

  // ── каталог не загружен ────────────────────────────────────────────────
  const пусто = await page.evaluate(() => {
    const было = D.catalog;
    D.catalog = { kinds: [], price: [] };
    const h = SCREENS.book();
    D.catalog = было;
    return h;
  });
  t('С.8 пустой каталог назван честно',
     /Справочник ещё не загрузился/.test(пусто) && !/нет ни одной активной позиции/.test(пусто),
     (пусто.match(/<span class="k">[^<]{0,90}/) || [''])[0]);

  // ── нет настоящих запретов вовсе ───────────────────────────────────────
  const безЗапретов = await page.evaluate(() => {
    const было = D.catalog.price;
    D.catalog.price = было.filter(p => p.code !== 'ML-03');
    const h = SCREENS.book();
    D.catalog.price = было;
    return h;
  });
  t('С.7 нет настоящих запретов → блока нет',
     !/Запрещено для себя/.test(безЗапретов) && !/· запрещено /.test(безЗапретов),
     (безЗапретов.match(/Запрещено[^<]*/) || [''])[0]);
  t('С.7 но служебные всё равно названы',
     /строк(и|) прайса относятся/.test(безЗапретов), 'служебные пропали вместе с блоком');

  console.log('\n=== 181.16 · запрещено это выбор ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
