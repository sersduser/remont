/*
  Стенд Д-181-2 — при остановленном обновлении экран не притворяется рабочим.

  Повод: живой проход 22.08, скрины 1310 и 1312. Панель сказала «Обновление
  остановлено», а плитки под полосой продолжали нажиматься. Слова Дмитрия:
  «страница зависла».

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 после остановки обновления поверх экрана есть маска;
    С.2 маска перекрывает плитки главного экрана (геометрия, а не наличие);
    С.3 полоса с объяснением остаётся ВЫШЕ маски — её видно и по ней можно нажать;
    С.4 текст полосы не изменился (регресс слов);
    С.5 без остановки обновления маски нет вовсе.

  Запуск: node стенд_экран_181_3.js <сборка.html>
  Обязан падать на 181.2 и проходить на 181.3.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_3.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const данные = () => ({ ok: true, role: 'owner', kind: 'owner', title: 'Стенд остановки',
  object_id: '019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who: 'Тест', object_verified: true, objectVia: 'key',
  rooms: [{ code: 'ZL', name: 'Зал', kind: 'жилая', floor_m2: 16, perimeter_m: 16, height_m: 2.8, wall_m2: 39, ceiling_m2: 16 }],
  elements: [], adjacency: [], works: [], catalog: { kinds: [], price: [] }, price: [], access: [],
  modifiers: [], docs: [], drafts: [], crew: [], payments: [], changes: [], settings: {},
  my_money: null, materials: [], log: [], accepts: [], extras: [] });

(async () => {
  const порт = 8600 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0, 2).join(' | '));

  const до = await page.evaluate(() => ({ маска: !!document.getElementById('staleMask') }));
  t('С.5 без остановки обновления маски нет', до.маска === false);

  const из = await page.evaluate(() => {
    staleStop();
    const м = document.getElementById('staleMask');
    const п = document.getElementById('staleBar');
    const плитка = document.querySelector('.tile');
    const рез = { маска: !!м, полоса: !!п, текст: п ? п.textContent.slice(0, 40) : '' };
    if (м && плитка) {
      const a = м.getBoundingClientRect(), b = плитка.getBoundingClientRect();
      рез.перекрывает = !(a.bottom <= b.top || a.top >= b.bottom || a.right <= b.left || a.left >= b.right);
      рез.zМаски = Number(getComputedStyle(м).zIndex);
    }
    if (п) рез.zПолосы = Number(getComputedStyle(п).zIndex);
    return рез;
  });

  t('С.1 после остановки обновления есть маска', из.маска === true);
  t('С.2 маска перекрывает плитки главного экрана', из.перекрывает === true, 'перекрытие ' + из.перекрывает);
  t('С.3 полоса выше маски', из.zПолосы > из.zМаски, 'полоса ' + из.zПолосы + ' против маски ' + из.zМаски);
  t('С.4 текст полосы прежний', /Обновление остановлено/.test(из.текст), из.текст);

  await br.close(); сервер.close();
  console.log('СТЕНД Д-181-2 · ' + path.basename(FILE));
  ok.forEach(s => console.log('  ✓ ' + s));
  bad.forEach(s => console.log('  ✗ ' + s));
  console.log(`ИТОГ: ${ok.length}/${ok.length + bad.length}`);
  process.exit(bad.length ? 1 : 0);
})();
