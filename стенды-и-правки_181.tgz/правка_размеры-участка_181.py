# -*- coding: utf-8 -*-
"""Чат 181 · Д-181-9: участок проёма можно описать — размеры прямо в его окне.

Повод — живой проход 23.08, скрин 1379. Дмитрий: «Нажав на кнопку
"...непрямоугольный...", попал сюда. Не вижу инструментов, описать г-образный
проём. Подскажи.»

Участок создавался с пустыми размерами, тост говорил «задайте его размеры» — и
открывалось окно, где полей размеров не было вовсе. Механизм заведён наполовину:
сущность есть, инструментов нет. Размеры при этом спрашивались опросом («ширина
и высота?») — то есть данные панель принимает, но только в одном месте и только
когда сама спросит.

Правка кладёт поля туда, где человек их ищет: в окно самого проёма. Заодно
участок перестаёт быть безымянным — окно говорит, частью какого проёма он
является и сколько погонных метров дают все участки вместе. Сумма важнее
отдельных чисел: ради неё контур и дробится.
"""
import io, hashlib, sys

ФАЙЛ = sys.argv[1] if len(sys.argv) > 1 else '/tmp/panel_181_13.html'
т = io.open(ФАЙЛ, encoding='utf-8').read()
было = len(т.encode('utf-8'))

def замена(старое, новое, имя):
    global т
    n = т.count(старое)
    assert n == 1, f'{имя}: вхождений {n}, а нужно ровно 1'
    т = т.replace(старое, новое, 1)
    print(f'  ✓ {имя}')

# ── 1. Запись размеров ─────────────────────────────────────────────────────
старое1 = """async function elemSet(id, field, value){"""
новое1 = """/* ── Размеры проёма прямо в его окне [181, Д-181-9] ───────────────────────
   Раньше ширину и высоту принимал только опрос, когда сам о них спрашивал.
   Человек, открывший проём руками, полей не находил — и описать г-образную
   форму участками не мог, хотя сами участки заводились. */
async function elemSizeSave(id){
  if(typeof ELEM_BUSY !== "undefined" && ELEM_BUSY) return;
  const чис = (s) => {
    const v = Number(String(s == null ? "" : s).replace(",", ".").trim());
    if(!isFinite(v) || v <= 0) return null;
    return v > 20 ? Math.round(v) / 100 : v;      // 90 → 0,9: сантиметры принимаем как есть
  };
  const w = чис((document.getElementById("elemW") || {}).value);
  const h = чис((document.getElementById("elemH") || {}).value);
  if(w === null && h === null){ toast("Впишите ширину и высоту", "err"); return; }
  if(typeof ELEM_BUSY !== "undefined") ELEM_BUSY = true;
  try{
    if(w !== null) await writeCell("13_Элементы", id, "Ширина_м", String(w));
    if(h !== null) await writeCell("13_Элементы", id, "Высота_м", String(h));
    const e = elemAll().find(x => x.id === id);
    if(e){ if(w !== null) e.w = w; if(h !== null) e.h = h; }
    toast("Размеры записаны");
    render();
    elemEdit(id);
  }catch(err){ toast(err.message, "err"); }
  finally{ if(typeof ELEM_BUSY !== "undefined") ELEM_BUSY = false; }
}

async function elemSet(id, field, value){"""
замена(старое1, новое1, '1. функция elemSizeSave')

# ── 2. Блок размеров и сведения об участке в окне проёма ───────────────────
старое2 = """    '<div class="vd" style="margin-top:8px">Что было на плане БТИ</div>' +"""
новое2 = """    /* [181, Д-181-9] Размеры и принадлежность участка — выше судьбы: без них
       участок не описан, а судьба у него наследуется от проёма. */
    ((function(){
      const части = (typeof elemParts === "function") ? elemParts(id) : [e];
      const осн = (typeof elemKey === "function") ? elemKey(id) : id;
      const это_участок = String(id) !== String(осн);
      const мера = (v) => (Number(v) > 0 ? String(Math.round(Number(v) * 100) / 100) : "");
      let контур = 0;
      части.forEach(x => {
        const w = Number(x.w), h = Number(x.h);
        if(w > 0 && h > 0) контур += (String(x.fact || "") === "окно") ? (2 * (w + h)) : (w + 2 * h);
      });
      const шапка = (части.length > 1 || это_участок)
        ? '<div class="vd" style="margin-top:8px;color:var(--hint)">' +
            (это_участок ? ('Участок проёма <b>' + esc(осн) + '</b> · ') : '') +
            'участков: ' + части.length +
            (контур > 0 ? (' · контур вместе: <b>' + (Math.round(контур * 100) / 100) + '</b> пог.м') : ' · контур не посчитан — нет размеров') +
          '</div>'
        : '';
      return шапка +
        '<div class="vd" style="margin-top:8px">Размеры' + (это_участок ? ' этого участка' : '') + '</div>' +
        '<div style="display:flex;gap:8px;align-items:center;margin-top:4px">' +
          '<input id="elemW" type="number" step="0.01" inputmode="decimal" placeholder="ширина, м" value="' + esc(мера(e.w)) + '" ' +
            'style="flex:1;min-width:0;padding:9px;border-radius:10px;border:1px solid #3a3a3c;background:#000;color:#fff;font-size:15px">' +
          '<span style="opacity:.6">×</span>' +
          '<input id="elemH" type="number" step="0.01" inputmode="decimal" placeholder="высота, м" value="' + esc(мера(e.h)) + '" ' +
            'style="flex:1;min-width:0;padding:9px;border-radius:10px;border:1px solid #3a3a3c;background:#000;color:#fff;font-size:15px">' +
          '<button onclick="elemSizeSave(\\'' + esc(id) + '\\')" style="padding:9px 13px;border-radius:10px;border:0;background:#0a84ff;color:#fff;font-size:14px">Записать</button>' +
        '</div>';
    })()) +
    '<div class="vd" style="margin-top:8px">Что было на плане БТИ</div>' +"""
замена(старое2, новое2, '2. блок размеров в окне проёма')

# ── 3. Метка сборки ────────────────────────────────────────────────────────
старая = 'const BUILD = "181.12";'
assert т.count(старая) == 1
т = т.replace(старая, 'const BUILD = "181.13";', 1)
print('  ✓ 3. метка сборки: 181.12 → 181.13')

io.open(ФАЙЛ, 'w', encoding='utf-8').write(т)
стало = len(т.encode('utf-8'))
sha = hashlib.sha256(io.open(ФАЙЛ, 'rb').read()).hexdigest()[:16]
print(f'\nфайл: {было} → {стало} б (+{стало-было}), sha16 {sha}')
