/*
  Стенд 181.25 — отказ сервера объясняется человеку, а не цитируется.

  Повод: живой проход 23.08 по ссылке с ключом. Экран «Ход работ» показывал две
  строки: заголовок и «нужна подпись Telegram» — дословный текст серверного 401.
  Что закрыто, почему и что делать — не сказано ничего.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 отказ по подписи разобран: названы что, почему и что делать;
    С.2 машинной формулировки на экране больше нет;
    С.3 незнакомый отказ проходит как есть — объяснение не выдумывается;
    С.4 пустой отказ ничего не ломает;
    С.5 экран хода работ несёт объяснение целиком;
    С.6 регресс: при нормальном ответе экран прежний.

  Запуск: node стенд_отказ-по-подписи_181.js <сборка.html>
  Обязан падать на 181.24 и проходить на 181.25.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_25.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const данные = () => ({ ok:true, role:'admin', kind:'admin', title:'Стенд отказа',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[], elements:[], adjacency:[], works:[], catalog:{ kinds:[], price:[] }, price:[], access:[],
  modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9600 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof errHuman === 'function');
  t('функция errHuman существует', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const р = await page.evaluate(() => ({
    подпись: errHuman('нужна подпись Telegram'),
    другой:  errHuman('база недоступна'),
    пусто:   errHuman(''),
    ноль:    errHuman(null)
  }));
  t('С.1 отказ по подписи разобран', !!р.подпись, 'не разобран');
  t('С.1-bis названо, что закрыто', /только из Telegram/.test((р.подпись || {}).кратко || ''), JSON.stringify(р.подпись));
  t('С.1-ter названо, почему', /не говорит серверу, КТО/.test((р.подпись || {}).полно || ''), 'причина не названа');
  t('С.1-quater названо, что делать', /Откройте панель кнопкой из бота/.test((р.подпись || {}).полно || ''), 'шаг не назван');
  t('С.3 незнакомый отказ не выдумывается', р.другой === null, JSON.stringify(р.другой));
  t('С.4 пустой отказ ничего не ломает', р.пусто === null && р.ноль === null, 'пустое разобрано зря');

  const экран = await page.evaluate(() => {
    PLAN = { ok: false, error: 'нужна подпись Telegram' };
    return SCREENS.plan();
  });
  t('С.5 экран несёт объяснение', /только из Telegram/.test(экран) && /кнопкой из бота/.test(экран),
     экран.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').slice(0,160));
  t('С.2 машинной формулировки на экране нет',
     !/>нужна подпись Telegram</.test(экран), 'сырой текст остался');

  const целый = await page.evaluate(() => {
    PLAN = { ok: true, applied: true, stages: [], steps_done: 0, steps_total: 0, orphan_works: [] };
    return SCREENS.plan();
  });
  t('С.6 регресс: нормальный ответ экран не ломает',
     /Ход работ/.test(целый) && !/только из Telegram/.test(целый), целый.slice(0, 120));

  console.log('\n=== 181.25 · отказ по подписи ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
