/*
  Стенд 181.1 — погонные метры как третья мера объёма по схеме проёмов.

  Повод: решение Дмитрия 22.08 по карте «мера откосов» — путь В (гибрид):
  окна считаются метрами контура, двери остаются комплектом. До правки панель
  знала две меры: квадратные метры (площадь) и штуки; вид с единицей «п.м.»
  молча получал ШТУКИ, то есть смета за откос окна 2,07 × 1,52 и окна 0,90 × 1,40
  выставляла одно и то же число.

  Что меряется:
    О.0 страница поднялась без ошибок JS;
    О.1 окно считается полным периметром 2 × (ш + в);
    О.2 дверь считается без низа: ш + 2 × в (там порог, откоса нет);
    О.3 составной проём складывается по участкам (верхняя оценка, названная словами);
    О.4 проём без размеров в объём не входит — ноль честнее выдуманного периметра;
    О.5 подсказка называет, что считается контур, и предупреждает о составном;
    О.6 регресс: штуки и квадратные метры считаются как прежде.

  Запуск: node стенд_экран_181.js <сборка.html>
  Обязан падать на 180.9 и проходить на 181.1.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_1.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';
const близко = (a, b) => Math.abs(Number(a) - Number(b)) < 0.02;

/* Зал: окно к установке (1,32 × 1,52), дверь к замене (0,92 × 2,06),
   составной проём из двух участков (2,37 × 0,65 и 1,52 × 1,31) и окно без размеров. */
const данные = () => ({ ok: true, role: 'owner', kind: 'owner', title: 'Стенд меры откосов',
  object_id: '019fed2c-fad8-7b39-84b6-a2816d7295f2', who: 'Тест', object_verified: true, objectVia: 'key',
  rooms: [{ code: 'ZL', name: 'Зал', kind: 'жилая', floor_m2: 16.39, perimeter_m: 16.72, height_m: 2.81,
            wall_m2: 39.66, ceiling_m2: 16.39, windows: 2, doors: 1 }],
  elements: [
    { id: 'EL-09', a: 'ZL', b: 'улица', plan: 'окно', fact: 'окно', fate: 'заменить', w: 1.32, h: 1.52 },
    { id: 'EL-03', a: 'ZL', b: 'KR', plan: 'дверь', fact: 'дверь', fate: 'заменить', w: 0.92, h: 2.06 },
    { id: 'EL-02', a: 'ZL', b: 'BL', plan: 'проём', fact: 'проём', fate: 'заложить', w: 2.37, h: 0.65 },
    { id: 'EL-02.2', a: 'ZL', b: 'BL', plan: 'проём', fact: 'проём', fate: 'заложить', w: 1.52, h: 1.31 },
    { id: 'EL-13', a: 'ZL', b: 'улица', plan: 'окно', fact: 'окно', fate: 'заменить' },
  ],
  adjacency: [], works: [],
  catalog: { kinds: [
    { code: 'OK-06', name: 'Откосы оконные: отделка', unit: 'п.м.', base: 'окна:установить', section: 'Окна' },
    { code: 'DV-04', name: 'Наличники и добор', unit: 'компл', base: 'двери:установить', section: 'Двери' },
    { code: 'KL-06', name: 'Заделка проёма', unit: 'м²', base: 'проёмы:заложить', section: 'Кладка' },
    { code: 'DV-01', name: 'Установка двери', unit: 'шт', base: 'двери:установить', section: 'Двери' },
  ], price: [] },
  price: [], access: [], modifiers: [], docs: [], drafts: [], crew: [], payments: [], changes: [],
  settings: {}, my_money: null, materials: [], log: [], accepts: [], extras: [] });

(async () => {
  const порт = 8460 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  t('О.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0, 2).join(' | '));

  const из = await page.evaluate((d) => {
    D = d;
    const е = (typeof elemVol === 'function');
    const п = (typeof elemVolHint === 'function');
    return {
      естьФункции: е && п,
      окно_пм:    е ? elemVol('ZL', 'окна',  'установить', '', 'п.м.')  : 'НЕТ',
      дверь_пм:   е ? elemVol('ZL', 'двери', 'установить', '', 'п.м.')  : 'НЕТ',
      проём_пм:   е ? elemVol('ZL', 'проёмы','заложить',   '', 'п.м.')  : 'НЕТ',
      дверь_шт:   е ? elemVol('ZL', 'двери', 'установить', '', 'шт')    : 'НЕТ',
      проём_м2:   е ? elemVol('ZL', 'проёмы','заложить',   '', 'м²')    : 'НЕТ',
      подсказка:  п ? elemVolHint({ code:'OK-06', base:'окна:установить', unit:'п.м.' }, { code:'ZL' }) : 'НЕТ',
      подсказкаПроём: п ? elemVolHint({ code:'KL-06', base:'проёмы:заложить', unit:'п.м.' }, { code:'ZL' }) : 'НЕТ',
    };
  }, данные());

  /* Окно 1,32 × 1,52 → 2 × (1,32 + 1,52) = 5,68. Второе окно без размеров в счёт не идёт. */
  t('О.1 окно считается полным периметром', близко(из.окно_пм, 5.68), 'дало ' + из.окно_пм);
  /* Дверь 0,92 × 2,06 → 0,92 + 2 × 2,06 = 5,04. */
  t('О.2 дверь считается без низа', близко(из.дверь_пм, 5.04), 'дало ' + из.дверь_пм);
  /* Участки 2,37 × 0,65 и 1,52 × 1,31 → (2,37 + 1,30) + (1,52 + 2,62) = 7,81. */
  t('О.3 составной проём складывается по участкам', близко(из.проём_пм, 7.81), 'дало ' + из.проём_пм);
  t('О.4 проём без размеров в объём не вошёл', близко(из.окно_пм, 5.68) && из.окно_пм !== 0, 'дало ' + из.окно_пм);
  t('О.5 подсказка называет контур и предупреждает о составном',
    /контур/i.test(String(из.подсказка)) && /составн/i.test(String(из.подсказкаПроём)),
    'окно: ' + из.подсказка + ' | проём: ' + из.подсказкаПроём);
  t('О.6 регресс: штуки и квадратные метры прежние',
    Number(из.дверь_шт) === 1 && близко(из.проём_м2, 3.53), 'шт ' + из.дверь_шт + ', м² ' + из.проём_м2);

  await br.close(); сервер.close();
  console.log('СТЕНД МЕРЫ ОТКОСОВ · ' + path.basename(FILE));
  ok.forEach(s => console.log('  ✓ ' + s));
  bad.forEach(s => console.log('  ✗ ' + s));
  console.log(`ИТОГ: ${ok.length}/${ok.length + bad.length}`);
  process.exit(bad.length ? 1 : 0);
})();
