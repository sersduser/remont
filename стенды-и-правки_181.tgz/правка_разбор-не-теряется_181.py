# -*- coding: utf-8 -*-
"""Чат 181 · Д-181-4: разбор голоса переживает выход из окна.

Повод — живой проход 23.08 ночью. Дмитрий: «Вышел из этого окна и вернуться
невозможно — подтвердить данные не могу». Разбор жил только в памяти вкладки:
выход из Mini App стирал его вместе со всей наговорённой работой.

Правка: разбор кладётся в localStorage по объекту в тот же миг, когда строится
окно, — не по кнопке и не при закрытии, потому что закрытия человек может и не
делать (он просто выходит). На главном экране появляется плашка «вернуться к
разбору», сохранённое живёт сутки и стирается, когда работы перенесены в профиль.
"""
import io, hashlib, sys

ФАЙЛ = sys.argv[1] if len(sys.argv) > 1 else '/tmp/panel_181_6.html'
т = io.open(ФАЙЛ, encoding='utf-8').read()
было = len(т.encode('utf-8'))

def замена(старое, новое, имя):
    global т
    n = т.count(старое)
    assert n == 1, f'{имя}: вхождений {n}, а нужно ровно 1'
    т = т.replace(старое, новое, 1)
    print(f'  ✓ {имя}')

# ── 1. Хранилище разбора — рядом с showVRepair ─────────────────────────────
старое1 = """function showVRepair(d){
  const list = Array.isArray(d.rooms) ? d.rooms : [];"""
новое1 = """/* ── Разбор голоса переживает выход [181, Д-181-4] ─────────────────────────
   Слова Дмитрия из живого прохода 23.08: «Вышел из этого окна и вернуться
   невозможно — подтвердить данные не могу». Окно строилось из памяти вкладки,
   и выход из Mini App уносил всё наговорённое.

   Три решения, каждое от того, как человек на самом деле выходит:
   (1) кладём в тот же миг, когда окно СТРОИТСЯ, а не по кнопке «Отмена»:
       из Mini App выходят кнопкой Telegram, до нашей кнопки дело не доходит;
   (2) ключ несёт хвост ключа доступа — как у плана профиля (PLAN_LS), иначе
       разбор одного объекта всплыл бы на другом;
   (3) живёт сутки: разбор позавчерашнего разговора предлагать вреднее, чем
       не предлагать вовсе — человек примет его за сегодняшний. */
const VOICE_LS = "REMONT_VOICE";
function voiceKeepKey(){
  try{ return VOICE_LS + "_" + String(KEY || localStorage.getItem(OBJK_LS) || "-").slice(-12); }
  catch(e){ return VOICE_LS + "_-"; }
}
function voiceKeep(d){
  try{
    if(!d || !Array.isArray(d.rooms) || !d.rooms.length) return;
    localStorage.setItem(voiceKeepKey(), JSON.stringify({ at: Date.now(), d: d }));
  }catch(e){}
}
function voiceKept(){
  try{
    const s = localStorage.getItem(voiceKeepKey());
    if(!s) return null;
    const v = JSON.parse(s);
    if(!v || !v.d || !Array.isArray(v.d.rooms) || !v.d.rooms.length) return null;
    if(!(Date.now() - Number(v.at) < 24 * 60 * 60 * 1000)) return null;   // старше суток — молчим
    return v;
  }catch(e){ return null; }
}
function voiceForget(){ try{ localStorage.removeItem(voiceKeepKey()); }catch(e){} }
function voiceRestore(){
  const v = voiceKept();
  if(!v){ toast('Последнего разбора нет — он живёт сутки', 'err'); return; }
  showVRepair(v.d);
}
/* Плашка на главном: человек возвращается именно туда, а не в окно. */
function voiceKeptBox(){
  const v = voiceKept();
  if(!v) return "";
  const мин = Math.round((Date.now() - Number(v.at)) / 60000);
  const когда = мин < 1 ? "только что" : (мин < 60 ? (мин + " мин назад") : (Math.round(мин / 60) + " ч назад"));
  const скольких = v.d.rooms.length;
  const слово = скольких === 1 ? "помещению" : "помещениям";
  const сказано = String(v.d.recognized || "").slice(0, 90);
  return '<div class="warnbox">Последний разбор голоса — по ' + скольких + ' ' + слово + ', ' + esc(когда) + '.' +
    (сказано ? '<br><span style="color:var(--hint);font-size:13px">«' + esc(сказано) + '…»</span>' : '') +
    '<div style="margin-top:10px;display:flex;gap:8px">' +
      '<button onclick="voiceRestore()" style="flex:1;padding:12px;border-radius:12px;border:0;background:#0a84ff;color:#fff;font-size:15px">Вернуться к разбору</button>' +
      '<button onclick="voiceForget(); render()" style="padding:12px 14px;border-radius:12px;border:0;background:#3a3a3c;color:#fff;font-size:15px">Убрать</button>' +
    '</div></div>';
}

function showVRepair(d){
  const list = Array.isArray(d.rooms) ? d.rooms : [];
  voiceKeep(d);                                  // [181] кладём сразу, а не по кнопке"""
замена(старое1, новое1, '1. хранилище разбора')

# ── 2. Плашка на главном экране ────────────────────────────────────────────
старое2 = """    ${head}${cheki}
    <div class="grid">"""
новое2 = """    ${head}${cheki}${voiceKeptBox()}
    <div class="grid">"""
замена(старое2, новое2, '2. плашка на главном экране')

# ── 3. Забыть разбор, когда работы перенесены ──────────────────────────────
старое3 = """async function applyVoiceRepair(){"""
новое3 = """async function applyVoiceRepair(){
  /* [181] Перенесённое в профиль больше не «последний разбор»: плашка,
     которая предлагает вернуться к уже применённому, хуже её отсутствия. */
  const _забыть = () => { try{ voiceForget(); }catch(e){} };
  setTimeout(_забыть, 0);"""
замена(старое3, новое3, '3. очистка после переноса')

# ── 4. Метка сборки ────────────────────────────────────────────────────────
старая = 'const BUILD = "181.5";'
assert т.count(старая) == 1, 'метки сборки нет или их много'
т = т.replace(старая, 'const BUILD = "181.6";', 1)
print('  ✓ 4. метка сборки: 181.5 → 181.6')

io.open(ФАЙЛ, 'w', encoding='utf-8').write(т)
стало = len(т.encode('utf-8'))
sha = hashlib.sha256(io.open(ФАЙЛ, 'rb').read()).hexdigest()[:16]
print(f'\nфайл: {было} → {стало} б (+{стало-было}), sha16 {sha}')
