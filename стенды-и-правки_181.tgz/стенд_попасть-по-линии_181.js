/*
  Стенд 181.29 — по линии графа попадает тот проём, в который целились.

  Повод: слова Дмитрия 22.08 — «Сейчас выберу шахта-туалет» → «А выбирал
  шахта-туалет», открылся «Коридор ↔ подъезд». У плашки Коридора сходятся пять
  линий; их хитбоксы шириной 14, идущие во всю длину, у самого узла лежат друг
  на друге, и тык рядом с плашкой открывает соседний проём.

  Что меряется (геометрией, а не наличием элементов):
    С.0 страница поднялась без ошибок JS;
    С.1 у каждой линии есть свой хитбокс;
    С.2 хитбокс не начинается у самого узла — обрезан с обоих концов;
    С.3 хитбоксы двух линий из одного узла НЕ пересекаются у этого узла;
    С.4 середина линии по-прежнему попадает в свой проём;
    С.5 кружок-цель в середине на месте и стал больше;
    С.6 регресс: клик по хитбоксу зовёт elemEdit со своим id.

  Запуск: node стенд_попасть-по-линии_181.js <сборка.html>
  Обязан падать на 181.28 и проходить на 181.29.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_29.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

/* Пять дверей из одного Коридора — ровно боевая картина «Юнусабада 13». */
const комнаты = ['KR','VN','TL','ZL','SP','KH'].map((c,i) => ({
  code:c, name:{KR:'Коридор',VN:'Ванна',TL:'Туалет',ZL:'Зал',SP:'Спальня',KH:'Кухня'}[c],
  kind:'жилая', floor_m2:10+i, perimeter_m:12, height_m:2.8, wall_m2:30, ceiling_m2:10+i, windows:0, doors:1
}));
const элементы = [
  { id:'EL-01', name:'Коридор ↔ Ванна',   a:'KR', b:'VN', plan:'дверь', fact:'дверь', fate:'заменить',  w:0.9, h:2.05 },
  { id:'EL-02', name:'Коридор ↔ Туалет',  a:'KR', b:'TL', plan:'дверь', fact:'дверь', fate:'заложить',  w:0.7, h:2.05 },
  { id:'EL-03', name:'Коридор ↔ Зал',     a:'KR', b:'ZL', plan:'дверь', fact:'дверь', fate:'не трогаем',w:0.9, h:2.07 },
  { id:'EL-04', name:'Коридор ↔ Спальня', a:'KR', b:'SP', plan:'дверь', fact:'дверь', fate:'заменить',  w:0.9, h:2.07 },
  { id:'EL-05', name:'Коридор ↔ Кухня',   a:'KR', b:'KH', plan:'проём', fact:'проём', fate:'не трогаем',w:1.1, h:2.1 }
];
const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд графа',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms: комнаты, elements: элементы, adjacency:[], works:[], catalog:{ kinds:[], price:[] },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9800 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1400);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const г = await page.evaluate(() => {
    const h = SCREENS.object();
    const d = document.createElement('div'); d.innerHTML = h;
    const линии = [...d.querySelectorAll('line')].filter(l => (l.getAttribute('stroke') || '').indexOf('rgba(0,0,0,.01)') >= 0);
    const круги = [...d.querySelectorAll('circle')].filter(c => (c.getAttribute('fill') || '').indexOf('rgba(0,0,0,.01)') >= 0);
    const видимые = [...d.querySelectorAll('line')].filter(l => (l.getAttribute('stroke') || '').indexOf('rgba') < 0);
    const чит = l => ({
      id: (l.getAttribute('onclick') || '').replace(/[^']*'([^']+)'.*/, '$1'),
      x1: +l.getAttribute('x1'), y1: +l.getAttribute('y1'),
      x2: +l.getAttribute('x2'), y2: +l.getAttribute('y2'), w: +l.getAttribute('stroke-width')
    });
    return {
      хит: линии.map(чит),
      вид: видимые.map(чит),
      круги: круги.map(c => ({ r: +c.getAttribute('r'), id: (c.getAttribute('onclick') || '').replace(/[^']*'([^']+)'.*/, '$1') }))
    };
  });

  t('С.1 у каждой линии есть хитбокс', г.хит.length >= 5, 'хитбоксов ' + г.хит.length);

  /* Для каждой пары «видимая линия — её хитбокс» смотрим, отступил ли хитбокс
     от узла. Сравниваем по общему узлу KR: у всех линий он один и тот же. */
  const узел = г.вид.length ? { x: г.вид[0].x1, y: г.вид[0].y1 } : null;
  const дист = (p, q) => Math.hypot(p.x - q.x, p.y - q.y);
  const отступы = г.хит.map(h => Math.min(дист(узел, { x: h.x1, y: h.y1 }), дист(узел, { x: h.x2, y: h.y2 })));
  const минОтступ = Math.min.apply(null, отступы);
  t('С.2 хитбокс отступает от узла', минОтступ > 8, 'минимальный отступ ' + минОтступ.toFixed(1));

  /* С.3 — главное: расстояние между хитбоксами двух соседних линий у узла
     должно быть больше их полуширины, иначе они спорят за один тык. */
  const пересеклись = (() => {
    for(let i = 0; i < г.хит.length; i++){
      for(let j = i + 1; j < г.хит.length; j++){
        const a = г.хит[i], b = г.хит[j];
        const к1 = дист({ x:a.x1, y:a.y1 }, { x:b.x1, y:b.y1 });
        if(к1 < (a.w + b.w) / 2 * 0.5) return a.id + ' и ' + b.id + ' сходятся на ' + к1.toFixed(1);
      }
    }
    return '';
  })();
  t('С.3 хитбоксы соседних линий не сходятся у узла', пересеклись === '', пересеклись);

  t('С.4 середина линии осталась в своём проёме',
     г.хит.every(h => h.w >= 14), 'ширина хитбокса упала');
  t('С.5 кружок-цель на месте и больше прежнего',
     г.круги.length >= 5 && г.круги.every(c => c.r >= 11), JSON.stringify(г.круги.slice(0,3)));
  t('С.6 клик зовёт elemEdit со своим id',
     г.хит.every(h => /^EL-\d+$/.test(h.id)) && new Set(г.хит.map(h => h.id)).size === г.хит.length,
     JSON.stringify(г.хит.map(h => h.id)));

  console.log('\n=== 181.29 · попасть по линии ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
