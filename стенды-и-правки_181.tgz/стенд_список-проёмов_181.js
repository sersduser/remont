/*
  Стенд Д-181-8 — по проёму можно попасть списком, а не только тыком в линию.

  Повод: живой проход 23.08. Дмитрий: «Сейчас выберу шахта-туалет» → «А выбирал
  шахта-туалет» — открылся «Коридор ↔ подъезд». Хитбокс линии расширен ещё в 141
  до 14 пикселей, но при пятнадцати проёмах линии идут рядом, и промах идёт не
  мимо линии, а В СОСЕДНЮЮ. Ширина хитбокса такой промах не лечит вовсе.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 под графом есть список проёмов строками;
    С.2 в строке названы оба конца, что там сейчас и что делаем;
    С.3 строка открывает тот же проём, что и линия (elemEdit с тем же id);
    С.4 показаны все проёмы, а не первые несколько;
    С.5 граф остался на месте — список не заменил его (регресс).

  Запуск: node стенд_список-проёмов_181.js <сборка.html>
  Обязан падать на 181.8 и проходить на 181.9.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const комната = (code, name) => ({ code, name, title:name, kind:'жилая', floor_m2:10, perimeter_m:13,
  height_m:2.8, wall_m2:30, walls_m2:30, ceiling_m2:10, windows_cnt:1, doors_cnt:1 });
const проём = (id, a, b, fact, fate) => ({ id, name:a + ' ↔ ' + b, a, b, plan:fact, fact, fate, w:0.9, h:2.1 });

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд списка проёмов',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[ комната('SH','Шахта'), комната('TL','Туалет'), комната('KR','Коридор'), комната('ZL','Зал') ],
  elements:[ проём('E1','Шахта','Туалет','дверь','не трогаем'),
             проём('E2','Коридор','подъезд','дверь','заменить'),
             проём('E3','Коридор','Зал','проём',''),
             проём('E4','Зал','улица','окно','не трогаем') ],
  adjacency:[{a:'SH',b:'TL'},{a:'KR',b:'ZL'}], works:[], catalog:{ kinds:[], price:[] },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9500 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const из = await page.evaluate(() => {
    try{
      if(typeof go === 'function') go('object'); else if(typeof SCREEN !== 'undefined'){ SCREEN='object'; render(); }
      return null;
    }catch(e){ return { нет:e.message }; }
  });
  await page.waitForTimeout(600);

  const экран = await page.evaluate(() => ({
    html: document.body.innerHTML,
    текст: document.body.innerText
  }));
  const html = экран.html || '', текст = экран.текст || '';

  t('С.5 граф остался на месте', /<svg/i.test(html) && /<line/i.test(html), 'нет svg с линиями');

  /* Список ищем как блок со строками проёмов вне svg. */
  const внеSvg = html.replace(/<svg[\s\S]*?<\/svg>/gi, '');
  t('С.1 под графом есть список проёмов строками',
     /elemEdit\(/.test(внеSvg), 'вызовов elemEdit вне графа нет');

  t('С.2 в строке названы концы, факт и судьба',
     /Шахта[\s\S]{0,60}Туалет/.test(внеSvg) && /не трогаем|заменить/.test(внеSvg),
     внеSvg.slice(0, 0) + (текст.match(/Шахта[^\n]{0,80}/) || ['—'])[0]);

  const ид = await page.evaluate(() => {
    const внеSvg = document.body.innerHTML.replace(/<svg[\s\S]*?<\/svg>/gi, '');
    const м = внеSvg.match(/elemEdit\('([^']+)'\)/g) || [];
    return м.map(s => (s.match(/elemEdit\('([^']+)'\)/) || [])[1]);
  });
  t('С.3 строка открывает тот же проём, что и линия',
     ид.indexOf('E1') >= 0 && ид.indexOf('E2') >= 0, JSON.stringify(ид));
  t('С.4 показаны все проёмы', ['E1','E2','E3','E4'].every(x => ид.indexOf(x) >= 0), JSON.stringify(ид));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
