/*
  Стенд Д-181-9 — участок проёма можно описать: размеры прямо в его окне.

  Повод: живой проход 23.08, скрин 1379. Дмитрий: «Нажав на кнопку
  "...непрямоугольный...", попал сюда. Не вижу инструментов, описать г-образный
  проём. Подскажи.» Участок создаётся с пустыми размерами, тост говорит «задайте
  его размеры» — и открывается окно, где полей размеров нет вовсе.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 в окне проёма есть поля ширины и высоты;
    С.2 заданные размеры подставлены в поля;
    С.3 у участка сказано, частью какого проёма он является;
    С.4 у составного проёма видна сумма контура по участкам;
    С.5 есть чем записать размеры (функция сохранения).

  Запуск: node стенд_размеры-участка_181.js <сборка.html>
  Обязан падать на 181.12 и проходить на 181.13.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд участков',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'SP', name:'Спальня', title:'Спальня', kind:'жилая', floor_m2:16, perimeter_m:16,
           height_m:2.8, wall_m2:39, walls_m2:39, ceiling_m2:16 }],
  elements:[
    { id:'EL-08',   name:'Спальня ↔ Зал', a:'SP', b:'ZL', plan:'дверь', fact:'дверь', fate:'не трогаем', w:0.9,  h:2.1 },
    { id:'EL-08.2', name:'Спальня ↔ Зал', a:'SP', b:'ZL', plan:'дверь', fact:'проём', fate:'не трогаем', w:0.45, h:0.6 }
  ],
  adjacency:[], works:[], catalog:{ kinds:[], price:[] }, price:[], access:[],
  modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9900 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const из = await page.evaluate(() => {
    try{
      elemEdit('EL-08.2');
      const л = document.querySelector('.vmask');
      return { html:(л ? л.innerHTML : '').slice(0, 6000), текст:(л ? л.innerText : '').slice(0, 1200),
               есть: typeof elemSizeSave === 'function' };
    }catch(e){ return { нет:e.message }; }
  });
  await page.waitForTimeout(300);
  const html = из.html || '', текст = из.текст || '';

  t('С.1 в окне проёма есть поля ширины и высоты',
     /id="elemW"/.test(html) && /id="elemH"/.test(html), (из.нет || текст.slice(0,180)));
  t('С.2 заданные размеры подставлены',
     /value="0\.45"/.test(html) && /value="0\.6"/.test(html), (html.match(/id="elem[WH]"[^>]*/g) || []).join(' | '));
  t('С.3 сказано, частью какого проёма является участок',
     /EL-08(?!\.)/.test(текст) && /участок/i.test(текст), текст.slice(0, 200));
  t('С.4 видна сумма контура по участкам',
     /контур|пог\.?\s*м/i.test(текст), текст.slice(0, 200));
  t('С.5 есть чем записать размеры', из.есть === true, String(из.есть));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
