/*
  Стенд Д-181-3 — что значит судьба, видно ДО выбора, а не после.

  Повод: вопрос Дмитрия от 18.08 «Что значит кнопка "установить"?» (снимок 1191).
  В 158.3 под кнопками появилось пояснение словами — но только для УЖЕ выбранной
  судьбы: FATE_HINT[e.fate]. Вопрос же задаётся ДО нажатия, когда e.fate пуст,
  и человек по-прежнему видит семь коротких слов без объяснения.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 окно проёма открылось;
    С.2 при НЕ выбранной судьбе видно, что значит каждое слово (все семь);
    С.3 при не выбранной судьбе видно именно спорную пару «пробить» / «установить»;
    С.4 при выбранной судьбе пояснение выбранного осталось (регресс 158.3);
    С.5 при выбранной судьбе есть ход «показать все» — сверить соседние слова;
    С.6 сами тексты пояснений не потеряны и не переписаны.

  Запуск: node стенд_подсказка-судьбы_181.js <сборка.html>
  Обязан падать на 181.4 и проходить на 181.5.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const элементы = [
  { id:'EL-01', name:'Проём в кухню', a:'Коридор', b:'Кухня', plan:'дверь', fact:'дверь', fate:'' },
  { id:'EL-02', name:'Окно зала',     a:'Зал',     b:'улица', plan:'окно',  fact:'окно',  fate:'заменить' }
];

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд подсказки',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements: элементы, adjacency:[], works:[], catalog:{ kinds:[], price:[] }, price:[], access:[],
  modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 8800 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  // проём БЕЗ выбранной судьбы
  const без = await page.evaluate(() => {
    try{
      if(typeof elemEdit !== 'function') return { нет:'нет elemEdit' };
      elemEdit('EL-01');
      const el = document.querySelector('.vsheet, #vsheet, .vwrap') || document.body;
      return { текст: (el.innerText || '').slice(0, 2500) };
    }catch(e){ return { нет: e.message }; }
  });
  await page.waitForTimeout(300);
  const текстБез = без.текст || '';
  t('С.1 окно проёма открылось', /Что делаем в ремонте/.test(текстБез), (без.нет || текстБез.slice(0,120)));

  const все = [
    'Остаётся как есть',
    'старое полотно снимаем',
    'Снимаем полотно и не ставим ничего',
    'Закрываем проём стеной',
    'Делаем новый проём там, где стена была глухой',
    'Здесь закладываем, рядом пробиваем',
    'Проём есть, а полотна нет'
  ];
  const виднеБез = все.filter(s => текстБез.indexOf(s) >= 0);
  t('С.2 при не выбранной судьбе видно, что значит каждое слово',
     виднеБез.length === 7, 'видно ' + виднеБез.length + ' из 7');
  t('С.3 видна спорная пара «пробить» / «установить»',
     текстБез.indexOf('Проём есть, а полотна нет') >= 0 &&
     текстБез.indexOf('Делаем новый проём там, где стена была глухой') >= 0,
     'одно из двух пояснений не показано до выбора');

  // проём С выбранной судьбой
  const с = await page.evaluate(() => {
    try{
      if(typeof closeVSheet === 'function') closeVSheet();
      elemEdit('EL-02');
      const el = document.querySelector('.vsheet, #vsheet, .vwrap') || document.body;
      return { текст:(el.innerText || '').slice(0, 2500),
               html:(el.innerHTML || '').slice(0, 6000) };
    }catch(e){ return { нет:e.message }; }
  });
  await page.waitForTimeout(300);
  const текстС = с.текст || '';
  t('С.4 при выбранной судьбе пояснение выбранного осталось',
     текстС.indexOf('старое полотно снимаем') >= 0, текстС.slice(0,150));
  t('С.5 при выбранной судьбе есть ход «показать все»',
     /fateAll|показать все|что значит/i.test(с.html || ''), 'хода сверки нет');

  const тексты = await page.evaluate(() => {
    try{ return Object.keys(FATE_HINT).length + ':' + Object.values(FATE_HINT).join('|').length; }
    catch(e){ return 'нет FATE_HINT'; }
  });
  t('С.6 тексты пояснений на месте и не переписаны', /^7:\d{3}/.test(String(тексты)), String(тексты));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
