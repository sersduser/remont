/*
  Стенд 181.17 — язык, объединение из названия, предмет вопросов.

  Повод: живой проход 23.08 по боевому объекту «Квартира Сорокиных».
    ① «Ещё 83 строк прайса относятся», «Ещё 41 видов рынок не оценивает»;
    ② помещение TL «Туалет (объединён с VN 05.08)» с пустым merged_into висело
       в списке с нулями, и опрос ставил про него вопрос works:TL;
    ③ «обмеры полны» в шапке против «9 не заполнено» в плитке.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 склонения: 1 строка · 2 строки · 5 строк · 1 вид · 2 вида · 5 видов;
    С.2 объединение читается из названия: помещение уходит из списка;
    С.3 источник признака назван словом «название»;
    С.4 поле merged_into главнее названия;
    С.5 название, ссылающееся на несуществующий код, помещение НЕ прячет;
    С.6 примечание в списке помещений говорит, что признак взят из названия;
    С.7 плитка опроса называет предмет вопросов, а не только их число;
    С.8 регресс: обычное помещение остаётся в списке;
    С.9 число вопросов в плитке равно сумме слагаемых и длине очереди [181.18].

  Запуск: node стенд_язык-и-объединение_181.js <сборка.html>
  Обязан падать на 181.16 и проходить на 181.17.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_17.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const комнаты = [
  { code:'ZL', name:'Зал (пом. 5)',                 kind:'жилая',   floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16, windows:0, doors:2, merged_into:'' },
  { code:'VN', name:'Ванная (пом. 3)',              kind:'санузел', floor_m2:4,  perimeter_m:9,  height_m:2.8, wall_m2:23, ceiling_m2:4,  windows:0, doors:1, merged_into:'' },
  { code:'TL', name:'Туалет (объединён с VN 05.08)',kind:'санузел', floor_m2:0,  perimeter_m:0,  height_m:2.85,wall_m2:0,  ceiling_m2:0,  windows:0, doors:1, merged_into:'' },
  { code:'KH', name:'Кухня (объединена с ZZ 01.01)',kind:'кухня',   floor_m2:5,  perimeter_m:9,  height_m:2.8, wall_m2:25, ceiling_m2:5,  windows:0, doors:0, merged_into:'' },
  { code:'BL', name:'Лоджия (пом. 1)',              kind:'лоджия',  floor_m2:8,  perimeter_m:12, height_m:2.8, wall_m2:29, ceiling_m2:8,  windows:2, doors:0, merged_into:'ZL' }
];
const элементы = [
  { id:'EL-02', name:'Коридор ↔ Зал', a:'ZL', b:'VN', plan:'дверь', fact:'дверь', fate:'заменить', w:0.91, h:2.07 },
  { id:'EL-07', name:'Зал ↔ Спальня', a:'ZL', b:'VN', plan:'дверь', fact:'дверь', fate:'',        w:0.92, h:2.07 },
  { id:'EL-09', name:'Зал ↔ Лоджия',  a:'ZL', b:'BL', plan:'окно',  fact:'проём', fate:'',        w:1.31, h:1.52 }
];
const виды = [
  { code:'ML-01', name:'Малярка стен', section:'Малярка', unit:'м²', base_usd:3, active:true },
  { code:'KF-01', name:'Кафель пол',   section:'Кафель',  unit:'м²', base_usd:8, active:true },
  { code:'KF-02', name:'Кафель стены', section:'Кафель',  unit:'м²', base_usd:9, active:true },
  { code:'OLD-1', name:'Старый вид',   section:'Прочее',  unit:'шт', base_usd:5, active:false }
];
const прайс = [
  { who:'Ю', code:'ML-01', name:'Малярка стен', unit:'м²', price_usd:4.60, active:true  },
  { who:'Ю', code:'OLD-1', name:'Старый вид',   unit:'шт', price_usd:5.00, active:false }
];

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд языка',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms: комнаты, elements: элементы, adjacency:[], works:[], catalog:{ kinds: виды, price: прайс },
  price: прайс, access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 8900 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof roomMergedSrc === 'function' && typeof qzWhatLeft === 'function');
  t('функции roomMergedSrc и qzWhatLeft существуют', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const скл = await page.evaluate(() => ({
    с1: скл(1,'строка','строки','строк'), с2: скл(2,'строка','строки','строк'), с5: скл(5,'строка','строки','строк'),
    в1: скл(1,'вид','вида','видов'),      в2: скл(2,'вид','вида','видов'),      в5: скл(5,'вид','вида','видов'),
    в11: скл(11,'вид','вида','видов'),    в21: скл(21,'вид','вида','видов'),    в41: скл(41,'вид','вида','видов')
  }));
  t('С.1 склонения строк', скл.с1==='строка' && скл.с2==='строки' && скл.с5==='строк', JSON.stringify(скл));
  t('С.1 склонения видов', скл.в1==='вид' && скл.в2==='вида' && скл.в5==='видов' && скл.в11==='видов' && скл.в21==='вид' && скл.в41==='вид', JSON.stringify(скл));

  const м = await page.evaluate(() => ({
    список: roomList().map(r=>r.code),
    слитые: roomsMerged().map(r=>r.code),
    источникTL: roomMergedSrc(roomByCode('TL')),
    источникBL: roomMergedSrc(roomByCode('BL')),
    кудаTL: roomMergedTo(roomByCode('TL')),
    кудаKH: roomMergedTo(roomByCode('KH'))
  }));
  t('С.2 TL ушёл из списка помещений по названию',
     !м.список.includes('TL') && м.слитые.includes('TL'), JSON.stringify(м.список));
  t('С.3 источник признака у TL — «название»', м.источникTL === 'название', м.источникTL);
  t('С.4 у BL признак из данных главнее', м.источникBL === 'данные' && м.слитые.includes('BL'), м.источникBL);
  t('С.5 KH ссылается на несуществующий код → в списке остаётся',
     м.список.includes('KH') && м.кудаKH === '', 'кудаKH=' + м.кудаKH);
  t('С.8 обычные помещения на месте', м.список.includes('ZL') && м.список.includes('VN'), JSON.stringify(м.список));

  const h = await page.evaluate(() => { PROF.room = ''; return SCREENS.profile(); });
  t('С.6 примечание называет источник признака',
     /признак взят из названия/.test(h), (h.match(/Объединённые[^<]*/) || [''])[0].slice(0,200));

  const об = await page.evaluate(() => ({
    h: SCREENS.object(), что: qzWhatLeft(),
    части: (typeof qzLeftParts === 'function') ? qzLeftParts() : null,
    очередь: (typeof qzQueue === 'function') ? (qzQueue() || []).length : -1
  }));
  t('С.7 плитка называет предмет вопросов',
     /вопрос(а|ов|)\: /.test(об.h) && /(судьб|размер|помещени)/.test(об.что), 'qzWhatLeft: ' + об.что);
  t('С.7 склонение внутри предмета верное',
     !/\d+ судьба проёма\b(?![аы])/.test(об.что) || /1 судьба проёма/.test(об.что), об.что);
  /* [181.18] Число в плитке и его расшифровка обязаны считаться одним проходом.
     В 181.17 число бралось из roomTodo (поля обмеров), а расшифровка из qzQueue
     (вопросы опроса) — и плитка сказала «9 вопросов: 6 · 1 · 7». Эта проверка
     ловит весь класс: сумма слагаемых равна названному числу. */
  const сумма = (об.что.match(/(\d+)\s/g) || []).reduce((s, x) => s + Number(x), 0);
  t('С.9 сумма слагаемых равна числу вопросов',
     об.части && об.части.всего === сумма && об.части.всего === об.очередь,
     'всего=' + (об.части && об.части.всего) + ' сумма=' + сумма + ' очередь=' + об.очередь);
  const вПлитке = Number((об.h.match(/>(\d+) вопрос/) || [])[1] || -1);
  t('С.9 плитка печатает то же число',
     вПлитке === об.очередь, 'в плитке ' + вПлитке + ', в очереди ' + об.очередь);

  const прайсЭкран = await page.evaluate(() => SCREENS.book());
  t('С.1 в прайсе «1 строка прайса относится»',
     /Ещё 1 строка прайса относится/.test(прайсЭкран), (прайсЭкран.match(/Ещё \d+ строк[^<:]*/) || [''])[0]);
  t('С.1 в прайсе «2 вида справочника не заведены»',
     /2<\/b> вида справочника не заведены/.test(прайсЭкран), (прайсЭкран.match(/<\/b>[^<]{0,40}/) || [''])[0]);

  console.log('\n=== 181.17 · язык и объединение ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
