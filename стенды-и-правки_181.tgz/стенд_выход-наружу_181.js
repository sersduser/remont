/*
  Стенд — признак «помещение с выходом наружу».

  Повод: вопрос Дмитрия от 18.08 «добавить в перечень подъезд/улица» и его же
  уточнение 23.08: «5.1 помечать помещение с выходом наружу». Бывают квартиры
  с двумя выходами, и знать, какое помещение выходит наружу, нужно и для порядка
  работ (выход заливается последним), и для сметы (входная дверь — не межкомнатная).

  Ключевое различие, без которого признак бессмысленен: ВЫХОД — это дверь или
  открытый проём наружу. Окно на улицу выходом не является, хотя сторона у него
  тоже внешняя.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 помещение с дверью в подъезд помечено «выход наружу»;
    С.2 помещение с окном на улицу НЕ помечено;
    С.3 помещение без внешних проёмов не помечено;
    С.4 признак виден в карточке помещения на экране «Объект»;
    С.5 есть ручная пометка для случая, когда схемы проёмов нет.

  Запуск: node стенд_выход-наружу_181.js <сборка.html>
  Обязан падать на 181.10 и проходить на 181.11.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const комната = (code, name) => ({ code, name, title:name, kind:'жилая', floor_m2:10, perimeter_m:13,
  height_m:2.8, wall_m2:30, walls_m2:30, ceiling_m2:10, windows_cnt:1, doors_cnt:1 });
const проём = (id, a, b, fact) => ({ id, name:a + ' ↔ ' + b, a, b, plan:fact, fact, fate:'не трогаем', w:0.9, h:2.1 });

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд выхода',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[ комната('KR','Коридор'), комната('ZL','Зал'), комната('SP','Спальня') ],
  elements:[ проём('E1','Коридор','подъезд','дверь'),   // выход
             проём('E2','Зал','улица','окно'),          // не выход: окно
             проём('E3','Коридор','Зал','проём') ],     // внутренний
  adjacency:[{a:'KR',b:'ZL'}], works:[], catalog:{ kinds:[], price:[] },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9700 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const прямо = await page.evaluate(() => {
    if(typeof roomHasExit !== 'function') return { нет:'нет roomHasExit' };
    return { KR: roomHasExit('KR'), ZL: roomHasExit('ZL'), SP: roomHasExit('SP'),
             ручная: typeof roomExitToggle === 'function' };
  });
  t('С.1 помещение с дверью в подъезд помечено', прямо.KR === true, JSON.stringify(прямо));
  t('С.2 помещение с окном на улицу НЕ помечено', прямо.ZL === false, JSON.stringify(прямо));
  t('С.3 помещение без внешних проёмов не помечено', прямо.SP === false, JSON.stringify(прямо));
  t('С.5 есть ручная пометка', прямо.ручная === true, JSON.stringify(прямо));

  await page.evaluate(() => { try{ go('object'); }catch(e){ try{ SCREEN='object'; render(); }catch(e2){} } });
  await page.waitForTimeout(600);
  const текст = await page.evaluate(() => document.body.innerText || '');
  t('С.4 признак виден в карточке помещения',
     /выход наружу/i.test(текст), (текст.match(/Коридор[^\n]{0,120}/) || ['—'])[0]);

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
