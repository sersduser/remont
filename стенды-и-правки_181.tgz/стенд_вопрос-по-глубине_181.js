/*
  Стенд Д-181-6 — опрос спрашивает по тому, чего не хватает, а не «что делаем» заново.

  Повод: живой проход 23.08, скрины 1333 и 1336. Экран «Опрос · Юнусабад 13»
  задаёт «Что делаем в помещении "Коридор"?» — вопрос нулевого уровня. Слова
  Дмитрия: «В предыдущих транзакциях уже ввёл данные по ремонту в коридоре.
  Уместным были бы уточнения про электроточки и т.п., но не такой общий вопрос».

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 в пустом помещении вопрос прежний — «Что делаем в помещении»;
    С.2 где названы поверхности, вопрос спрашивает про инженерку, а не «что делаем»;
    С.3 где названо и то и другое, вопроса о работах нет вовсе;
    С.4 подсказка второго вопроса перечисляет, что уже названо;
    С.5 счётчик вопросов не сломан: пройдено + осталось = всего.

  Запуск: node стенд_вопрос-по-глубине_181.js <сборка.html>
  Обязан падать на 181.7 и проходить на 181.8.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const kinds = [
  { code:'ML-22', section:'Малярка',   name:'Стены: покраска',  title:'Стены: покраска',  unit:'м²', active:true, base_usd:1.5, volume_base:'стены' },
  { code:'ML-12', section:'Малярка',   name:'Потолок: покраска',title:'Потолок: покраска',unit:'м²', active:true, base_usd:1.5, volume_base:'потолок' },
  { code:'PL-04', section:'Полы',      name:'Укладка финиша',   title:'Укладка финиша',   unit:'м²', active:true, base_usd:2.5, volume_base:'пол' },
  { code:'EL-09', section:'Электрика', name:'Розетка',          title:'Розетка',          unit:'шт', active:true, base_usd:7,   volume_base:'вручную' },
  { code:'SN-05', section:'Сантехника',name:'Разводка водоснабжения', title:'Разводка водоснабжения', unit:'пог.м', active:true, base_usd:2.95, volume_base:'вручную' }
];
const комната = (code, name) => ({ code, name, title:name, kind:'жилая', floor_m2:12, perimeter_m:14,
  height_m:2.8, wall_m2:34, walls_m2:34, ceiling_m2:12, windows_cnt:1, doors_cnt:1 });

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд опроса',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[ комната('PU','Пусто'), комната('PV','Поверхности'), комната('PL','Полный') ],
  elements:[], adjacency:[], works:[], catalog:{ kinds, price: kinds.map(k => (
    { code:k.code, name:k.name, unit:k.unit, price_usd:k.base_usd, active:true })) },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{}, my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9400 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const из = await page.evaluate(() => {
    try{
      /* Отмечаем в профиле: в «Поверхности» — стены/потолок/пол, в «Полный» — ещё и инженерку. */
      if(typeof PROF !== 'object' || !PROF) return { нет:'нет PROF' };
      PROF.plan = PROF.plan || {};
      PROF.plan['PV'] = { 'ML-22':1, 'ML-12':1, 'PL-04':1 };
      PROF.plan['PL'] = { 'ML-22':1, 'ML-12':1, 'PL-04':1, 'EL-09':1, 'SN-05':1 };
      const все = (typeof qzQueue === 'function') ? qzQueue() : null;
      if(!все) return { нет:'нет qzQueue' };
      const работ = все.filter(q => /^works2?:/.test(String(q.id||'')));
      return {
        всего: все.length,
        работ: работ.map(q => ({ id:q.id, room:q.room, text:q.text, hint:q.hint }))
      };
    }catch(e){ return { нет:e.message }; }
  });

  const по = (rc) => (из.работ || []).find(q => q.room === rc) || null;
  const пусто = по('PU'), пов = по('PV'), полн = по('PL');

  t('С.1 в пустом помещении вопрос прежний',
     !!пусто && /Что делаем в помещении/.test(пусто.text || ''),
     из.нет || JSON.stringify(пусто));
  t('С.2 где названы поверхности — спрашиваем про инженерку',
     !!пов && !/Что делаем в помещении/.test(пов.text || '') && /электрик|сантехник|инженер/i.test(пов.text || ''),
     JSON.stringify(пов));
  t('С.3 где названо всё — вопроса о работах нет',
     полн === null, JSON.stringify(полн));
  t('С.4 подсказка второго вопроса перечисляет уже названное',
     !!пов && /стен|потол|пол/i.test(пов.hint || ''), пов ? String(пов.hint) : '—');

  const счёт = await page.evaluate(() => {
    try{
      const все = qzQueue();
      return { всего: все.length, комнат: (D.rooms || []).length };
    }catch(e){ return { нет:e.message }; }
  });
  t('С.5 счётчик вопросов цел', счёт.всего >= 1 && !счёт.нет, JSON.stringify(счёт));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
