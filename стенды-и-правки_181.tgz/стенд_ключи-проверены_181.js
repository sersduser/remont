/*
  Стенд 181.26 — список объектов не обещает доступа, которого не проверял.

  Повод: живой проход 23.08. Экран «Выбор объекта» показывал пять строк, под
  каждой «доступ есть». Прямая проверка ключей: два объекта живы (200), три
  отвечают 403 — удалены чисткой 22.08. Панель обещала доступ в никуда.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 непроверенная строка говорит «ключ сохранён», а не «доступ есть»;
    С.2 кнопка проверки есть, пока есть что проверять;
    С.3 проверка ставит srv=1 живому и srv=0 мёртвому;
    С.4 имя живого объекта запоминается из ответа;
    С.5 мёртвая строка приглушается и получает «Забыть здесь»;
    С.6 подтверждённая строка говорит «доступ подтверждён»;
    С.7 отсутствие связи строку не хоронит;
    С.8 итог проверки назван числами.

  Запуск: node стенд_ключи-проверены_181.js <сборка.html>
  Обязан падать на 181.25 и проходить на 181.26.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_26.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const ЖИВОЙ = 'aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';
const МЁРТВЫЙ = 'bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb';
const НЕМОЙ = 'cccccccc-3333-4333-8333-cccccccccccc';
/* Живой, но НЕ открытый сейчас: только на нём видно подпись «доступ
   подтверждён» — у открытого стоит «открыт сейчас». */
const ЖИВОЙ2 = 'dddddddd-4444-4444-8444-dddddddddddd';

const объект = (title) => ({ ok:true, role:'admin', kind:'admin', title: title,
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works:[], catalog:{ kinds:[], price:[] }, price:[], access:[], modifiers:[],
  docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{}, my_money:null, materials:[],
  log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9700 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route => {
    const u = route.request().url();
    if(u.indexOf(МЁРТВЫЙ) >= 0) return route.fulfill({ status:403, contentType:'application/json', body: JSON.stringify({ ok:false, error:'нет доступа' }) });
    if(u.indexOf(НЕМОЙ) >= 0)   return route.abort('failed');
    const имя = (u.indexOf(ЖИВОЙ) >= 0) ? 'Юнусабад 13' : 'Квартира Сорокиных';
    return route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(объект(имя)) });
  });
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${ЖИВОЙ}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1400);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof objsProbeAll === 'function');
  t('функция objsProbeAll существует', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  await page.evaluate(([ж, м, н, ж2]) => {
    objsWrite([{ key: ж, title: '', ts: 4 }, { key: м, title: '', ts: 3 },
               { key: н, title: '', ts: 2 }, { key: ж2, title: '', ts: 1 }]);
  }, [ЖИВОЙ, МЁРТВЫЙ, НЕМОЙ, ЖИВОЙ2]);

  const до = await page.evaluate(() => objSelScreen());
  t('С.1 непроверенная строка не обещает доступа',
     /ключ сохранён — доступ не проверен/.test(до) && !/доступ есть/.test(до), 'обещание осталось');
  t('С.2 кнопка проверки есть', /Проверить ключи/.test(до), 'кнопки нет');

  await page.evaluate(() => objsProbeAll());
  await page.waitForTimeout(1200);

  const после = await page.evaluate(() => ({ список: objsAll(), экран: objSelScreen() }));
  const по = k => (после.список.find(o => o.key === k) || {});
  t('С.3 живой ключ подтверждён', по(ЖИВОЙ).srv === 1, JSON.stringify(по(ЖИВОЙ)));
  t('С.3-bis мёртвый ключ помечен', по(МЁРТВЫЙ).srv === 0, JSON.stringify(по(МЁРТВЫЙ)));
  t('С.4 имя живого объекта запомнено', по(ЖИВОЙ).title === 'Юнусабад 13', JSON.stringify(по(ЖИВОЙ)));
  t('С.7 немой ключ не похоронен', по(НЕМОЙ).srv === undefined, JSON.stringify(по(НЕМОЙ)));
  t('С.5 мёртвая строка приглушена и даёт «Забыть здесь»',
     /Сервер эту строку не подтвердил/.test(после.экран) && /Забыть здесь/.test(после.экран), 'приглушения нет');
  t('С.6 подтверждённая строка говорит об этом',
     /доступ подтверждён/.test(после.экран), 'подписи нет');
  t('С.6-bis живой неоткрытый объект тоже подтверждён', по(ЖИВОЙ2).srv === 1, JSON.stringify(по(ЖИВОЙ2)));
  t('С.8 итог назван числами',
     /Проверено: живых 2, без доступа 1/.test(после.экран),
     (после.экран.match(/Проверено:[^<]{0,60}/) || [''])[0]);

  console.log('\n=== 181.26 · ключи проверены ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
