/*
  Стенд «прайс группой» — запрет, возврат и цена разделом целиком.

  Повод: слова Дмитрия 22.08 — «применим поправки в виде изменения цены и
  запрета цены к отдельным видам работ ИЛИ ГРУППАМ РАБОТ». Сейчас в панели
  и запрет, и цена задаются по одной строке; у пилота 84 запрещённых строки,
  то есть 84 нажатия.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 у заголовка активного раздела есть кнопки группы;
    С.2 блок «Запрещено для себя» сгруппирован по разделам, а не свалкой;
    С.3 у заголовка запрещённого раздела есть кнопка возврата с числом строк;
    С.4 план возврата СЧИТАЕТ СТРОКИ, а не коды (грабля 109: дубли);
    С.5 план возврата исключает строки, у которых вид погашен в справочнике;
    С.6 план возврата исключает строки, у которых есть активный близнец;
    С.7 групповая цена накрывает все строки раздела, включая дубль.

  Запуск: node стенд_прайс-группой_181.js <сборка.html>
  Обязан падать на 181.3 и проходить на 181.4.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

/* Каталог собран так, чтобы в нём были все четыре случая разом:
   — Сантехника: две активных строки + две запрещённых, вид активен → возврат можно;
   — Электрика: одна запрещённая с ПОГАШЕННЫМ видом → возврат бесполезен;
   — Малярка: запрещённая строка, у которой есть активный БЛИЗНЕЦ того же кода;
   — Демонтаж: активный раздел с ДУБЛЕМ кода — на нём меряется счёт строк. */
const kinds = [
  { code:'SN-05', section:'Сантехника', name:'Разводка водоснабжения', title:'Разводка водоснабжения', unit:'пог.м', active:true,  base_usd:2.95 },
  { code:'SN-06', section:'Сантехника', name:'Разводка канализации',   title:'Разводка канализации',   unit:'пог.м', active:true,  base_usd:3.80 },
  { code:'SN-01', section:'Сантехника', name:'Байпас',                 title:'Байпас',                 unit:'шт',    active:true,  base_usd:12.00 },
  { code:'SN-02', section:'Сантехника', name:'Батарея',                title:'Батарея',                unit:'шт',    active:true,  base_usd:20.00 },
  { code:'EL-21', section:'Электрика',  name:'Фотофиксация узлов',     title:'Фотофиксация узлов',     unit:'компл', active:false, base_usd:0 },
  { code:'ML-12', section:'Малярка',    name:'Шпатлёвка стен',         title:'Шпатлёвка стен',         unit:'м²',    active:true,  base_usd:1.50 },
  { code:'DM-06', section:'Демонтаж',   name:'Сдир кафеля',            title:'Сдир кафеля',            unit:'м²',    active:true,  base_usd:3.00 },
  { code:'DM-07', section:'Демонтаж',   name:'Сдир обоев',             title:'Сдир обоев',             unit:'м²',    active:true,  base_usd:1.20 },
];
const price = [
  { code:'SN-05', name:'Разводка водоснабжения', unit:'пог.м', price_usd:2.95, active:true  },
  { code:'SN-06', name:'Разводка канализации',   unit:'пог.м', price_usd:3.80, active:true  },
  { code:'SN-01', name:'Байпас',                 unit:'шт',    price_usd:null, active:false },
  { code:'SN-02', name:'Батарея',                unit:'шт',    price_usd:null, active:false },
  { code:'EL-21', name:'Фотофиксация узлов',     unit:'компл', price_usd:null, active:false },
  { code:'ML-12', name:'Шпатлёвка стен',         unit:'м²',    price_usd:1.50, active:true  },
  { code:'ML-12', name:'Шпатлёвка стен',         unit:'м²',    price_usd:null, active:false },
  { code:'DM-06', name:'Сдир кафеля',            unit:'м²',    price_usd:3.00, active:true  },
  { code:'DM-06', name:'Сдир кафеля',            unit:'м²',    price_usd:3.00, active:true  },
  { code:'DM-07', name:'Сдир обоев',             unit:'м²',    price_usd:null, active:false },
];

const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд прайса',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works:[], catalog:{ kinds, price }, price:[], access:[],
  modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 8700 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  // открыть экран прайса
  const открыт = await page.evaluate(() => {
    try{ if(typeof go === 'function'){ go('book'); return true; }
         if(typeof nav === 'function'){ nav('book'); return true; }
         if(typeof SCREEN !== 'undefined'){ SCREEN = 'book'; render(); return true; }
         return false; }catch(e){ return 'ошибка: ' + e.message; }
  });
  await page.waitForTimeout(500);
  const html = await page.evaluate(() => document.body.innerHTML);
  t('С.0-bis экран прайса открылся', /Прайс исполнителя/.test(html), 'открытие: ' + открыт);

  t('С.1 у заголовка активного раздела есть кнопки группы',
     /bookGroup(Ask|Price|Off)\(/.test(html), 'нет вызовов bookGroup* в разметке');

  const грп = await page.evaluate(() => {
    const тек = document.body.innerText;
    const i = тек.indexOf('Запрещено для себя');
    if(i < 0) return { нет: true };
    const хвост = тек.slice(i, i + 1200);
    return {
      разделы: ['Сантехника','Демонтаж'].filter(s => хвост.indexOf(s) >= 0),
      служебные: ['Электрика','Малярка'].filter(s => хвост.indexOf(s) >= 0),
      возврат: /Вернуть раздел/.test(хвост),
      хвост: хвост.slice(0, 300)
    };
  });
  /* [181.16] Ожидание переписано. Прежде здесь стояли Сантехника · Электрика ·
     Малярка — то есть ВСЕ выключенные строки. С 181.16 в блок «Запрещено для
     себя» попадает только выбор бригадира: Электрика (вид погашен) и Малярка
     (есть активный близнец) ушли в служебную строку под блоком. Проверка
     сохраняет смысл — группировка по разделам и кнопка возврата, — но меряет
     её на двух разделах настоящих запретов. */
  t('С.2 блок запрещённых сгруппирован по разделам',
     !грп.нет && грп.разделы.length === 2 && грп.возврат,
     'разделы в блоке: ' + JSON.stringify(грп.разделы || []) + ' · возврат: ' + грп.возврат);
  t('С.2-bis служебные разделы в блок не попали',
     !грп.нет && грп.служебные.length === 0,
     'просочились: ' + JSON.stringify(грп.служебные || []));

  const план = await page.evaluate(() => {
    if(typeof bookGroupPlan !== 'function') return { нет: 'нет функции bookGroupPlan' };
    return {
      сантех:   bookGroupPlan('Сантехника', 'on'),
      электро:  bookGroupPlan('Электрика',  'on'),
      малярка:  bookGroupPlan('Малярка',    'on'),
      демонтаж: bookGroupPlan('Демонтаж',   'price')
    };
  });
  t('С.4 план возврата считает строки, а не коды',
     план.сантех && план.сантех.rows === 2 && план.сантех.codes === 2,
     JSON.stringify(план.сантех || план));
  t('С.5 план возврата исключает строки с погашенным видом',
     план.электро && план.электро.rows === 0 && (план.электро.kindOff || 0) === 1,
     JSON.stringify(план.электро || план));
  t('С.6 план возврата исключает строки с активным близнецом',
     план.малярка && план.малярка.rows === 0 && (план.малярка.twin || 0) === 1,
     JSON.stringify(план.малярка || план));
  t('С.7 групповая цена накрывает обе строки дубля',
     план.демонтаж && план.демонтаж.rows === 2,
     JSON.stringify(план.демонтаж || план));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
