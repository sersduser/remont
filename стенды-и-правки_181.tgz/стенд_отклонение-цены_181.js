/*
  Стенд — отклонение цены бригадира от средней, стрелкой и процентом.

  Повод: слова Дмитрия 23.08 — «возле цены должна быть стрелка вверх или вниз и
  проценты, отличающиеся от средней цены по приложению. Если выше, то красные,
  а если ниже, то зелёные».

  Цветовая логика — от бригадира: дорого = красное (риск не выиграть заказ),
  дёшево = зелёное (конкурентен). Это обратно окраске «выгодно/невыгодно»
  с точки зрения продавца, и путать нельзя.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 цена выше ориентира — стрелка вверх и красный;
    С.2 цена ниже — стрелка вниз и зелёный;
    С.3 цена равна ориентиру — пометки нет вовсе;
    С.4 ориентира нет — пометки нет (не с чем сравнивать);
    С.5 процент считается верно: 12 против 10 = 20 %.

  Запуск: node стенд_отклонение-цены_181.js <сборка.html>
  Обязан падать на 181.9 и проходить на 181.10.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const kinds = [
  { code:'A-01', section:'Малярка', name:'Дороже средней', title:'Дороже средней', unit:'м²', active:true, base_usd:10 },
  { code:'A-02', section:'Малярка', name:'Дешевле средней', title:'Дешевле средней', unit:'м²', active:true, base_usd:10 },
  { code:'A-03', section:'Малярка', name:'Ровно средняя',   title:'Ровно средняя',   unit:'м²', active:true, base_usd:10 },
  { code:'A-04', section:'Малярка', name:'Без ориентира',   title:'Без ориентира',   unit:'м²', active:true, base_usd:0 }
];
const price = [
  { code:'A-01', name:'Дороже средней',  unit:'м²', price_usd:12,  active:true },
  { code:'A-02', name:'Дешевле средней', unit:'м²', price_usd:8.5, active:true },
  { code:'A-03', name:'Ровно средняя',   unit:'м²', price_usd:10,  active:true },
  { code:'A-04', name:'Без ориентира',   unit:'м²', price_usd:7,   active:true }
];
const данные = () => ({ ok:true, role:'owner', kind:'owner', title:'Стенд отклонения',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал', title:'Зал', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, walls_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works:[], catalog:{ kinds, price }, price:[], access:[],
  modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9600 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body:JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  await page.evaluate(() => { try{ openBook(); }catch(e){ try{ go('book'); }catch(e2){} } });
  await page.waitForTimeout(500);

  const из = await page.evaluate(() => {
    const html = document.body.innerHTML;
    const блок = (код) => {
      const i = html.indexOf(код);
      return i < 0 ? '' : html.slice(Math.max(0, i - 400), i + 700);
    };
    return {
      есть: typeof priceDelta === 'function',
      A1: блок('A-01'), A2: блок('A-02'), A3: блок('A-03'), A4: блок('A-04'),
      прямо: (typeof priceDelta === 'function') ? [priceDelta('A-01'), priceDelta('A-02'), priceDelta('A-03'), priceDelta('A-04')] : null
    };
  });

  const красный = /#ff\s*3b\s*30|#ff453a|#ff375f|color:#ff[0-9a-f]{4}/i;
  const зелёный = /#30d158|#34c759|#32d74b/i;

  t('С.1 дороже — стрелка вверх и красный',
     /▲/.test(из.A1 || '') && красный.test(из.A1 || ''), (из.A1 || '').slice(-220));
  t('С.2 дешевле — стрелка вниз и зелёный',
     /▼/.test(из.A2 || '') && зелёный.test(из.A2 || ''), (из.A2 || '').slice(-220));
  t('С.3 ровно средняя — пометки нет',
     !/▲|▼/.test(из.A3 || ''), (из.A3 || '').slice(-160));
  t('С.4 без ориентира — пометки нет',
     !/▲|▼/.test(из.A4 || ''), (из.A4 || '').slice(-160));
  t('С.5 процент считается верно (12 против 10 = 20 %)',
     /\b20\s*%/.test(из.A1 || '') || (из.прямо && /20/.test(String(из.прямо[0]))),
     JSON.stringify(из.прямо));

  await br.close(); сервер.close();
  console.log('\n=== ЗЕЛЁНЫЕ (' + ok.length + ') ===');   ok.forEach(s => console.log('  ✓ ' + s));
  console.log('\n=== КРАСНЫЕ (' + bad.length + ') ==='); bad.forEach(s => console.log('  ✗ ' + s));
  console.log('\nИТОГ: ' + ok.length + '/' + (ok.length + bad.length));
  process.exit(bad.length ? 1 : 0);
})();
