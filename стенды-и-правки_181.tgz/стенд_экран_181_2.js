/*
  Стенд Д-181-1 — подсказка не закрывает кнопки нижнего окна.

  Повод: живой проход Дмитрия 22.08, скрины 1306→1308. В окне «Обмеры помещений»
  он нажал «Записать отмеченное» до отметки строки, получил подсказку «Ничего не
  отмечено — коснитесь строки, чтобы отметить», подсказка легла ПОВЕРХ кнопок и
  провисела 25 секунд (TOAST_WAIT_MS). Он коснулся строки — она отметилась, —
  а кнопки записи не увидел.

  Что меряется — геометрией, а не словами:
    П.0 страница поднялась без ошибок JS;
    П.1 при открытом нижнем окне подсказка не перекрывает кнопку записи;
    П.2 при открытом окне подсказка получает признак «наверху»;
    П.3 подсказка при этом видна (не спрятана за край экрана);
    П.4 регресс: без открытого окна подсказка по-прежнему внизу;
    П.5 регресс: текст подсказки не изменился.

  Запуск: node стенд_экран_181_2.js <сборка.html>
  Обязан падать на 181.1 и проходить на 181.2.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_2.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const данные = () => ({ ok: true, role: 'owner', kind: 'owner', title: 'Стенд подсказки',
  object_id: '019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who: 'Тест', object_verified: true, objectVia: 'key',
  rooms: [{ code: 'SN', name: 'Санузел', kind: 'мокрая', floor_m2: 3, perimeter_m: 7, height_m: 2.8, wall_m2: 16, ceiling_m2: 3 }],
  elements: [{ id: 'EL-01', a: 'SN', b: 'ZL', plan: 'дверь', fact: 'дверь', fate: 'заменить', w: 0.9, h: 2.06 }],
  adjacency: [], works: [], catalog: { kinds: [], price: [] }, price: [], access: [], modifiers: [],
  docs: [], drafts: [], crew: [], payments: [], changes: [], settings: {}, my_money: null,
  materials: [], log: [], accepts: [], extras: [] });

(async () => {
  const порт = 8530 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1200);
  t('П.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0, 2).join(' | '));

  const из = await page.evaluate(() => {
    const рез = {};
    /* открываем нижнее окно с кнопкой записи — как в живом проходе */
    openVSheet('<div class="vh">Обмеры помещений</div>' +
      '<div class="vrow"><button class="vbtn-cancel" id="прб-отмена">Отмена</button>' +
      '<button class="vbtn-ok" id="прб-запись">Записать отмеченное</button></div>');
    toast('Ничего не отмечено — коснитесь строки, чтобы отметить', 'wait');
    const тост = document.getElementById('toast');
    const кнопка = document.getElementById('прб-запись');
    const a = тост.getBoundingClientRect(), b = кнопка.getBoundingClientRect();
    рез.наЛисте = { класс: тост.className, текст: тост.textContent,
      перекрытие: !(a.bottom <= b.top || a.top >= b.bottom),
      виден: a.top >= 0 && a.bottom <= window.innerHeight };
    closeVSheet();
    toast('Сохранено');
    const c = document.getElementById('toast').getBoundingClientRect();
    рез.безЛиста = { класс: document.getElementById('toast').className,
      снизу: c.top > window.innerHeight / 2 };
    return рез;
  });

  t('П.1 подсказка не перекрывает кнопку записи', из.наЛисте.перекрытие === false,
    'перекрытие ' + из.наЛисте.перекрытие);
  t('П.2 при открытом окне у подсказки признак «наверху»', /\bup\b/.test(из.наЛисте.класс),
    'класс: ' + из.наЛисте.класс);
  t('П.3 подсказка видна на экране', из.наЛисте.виден === true);
  t('П.4 регресс: без окна подсказка по-прежнему внизу', из.безЛиста.снизу === true,
    'класс: ' + из.безЛиста.класс);
  t('П.5 регресс: текст подсказки прежний',
    из.наЛисте.текст === 'Ничего не отмечено — коснитесь строки, чтобы отметить', из.наЛисте.текст);

  await br.close(); сервер.close();
  console.log('СТЕНД Д-181-1 · ' + path.basename(FILE));
  ok.forEach(s => console.log('  ✓ ' + s));
  bad.forEach(s => console.log('  ✗ ' + s));
  console.log(`ИТОГ: ${ok.length}/${ok.length + bad.length}`);
  process.exit(bad.length ? 1 : 0);
})();
