/*
  Стенд 181.15 — «из чего сложилась средняя» видна бригадиру.

  Повод: вопрос Дмитрия в боте — «5) где это "что-то" видит бригадир???».
  Стрелка отклонения говорит НАСКОЛЬКО, но молчит, ИЗ ЧЕГО средняя сложилась.

  Что меряется:
    С.0  страница поднялась без ошибок JS;
    С.1  средней нет  → строки происхождения нет вовсе (не пустая, а отсутствует);
    С.2  средняя есть → названы число, работы, объём;
    С.3  якорь жив    → сказано «стартовая цена ещё учитывается»;
    С.4  якорь мёртв  → про стартовую цену не сказано;
    С.5  работ ноль   → сказано «своих работ за 30 суток ещё нет», объём не выдуман;
    С.6  склонение по числу работ: 1 работа · 2 работы · 5 работ · 11 работ · 21 работа;
    С.7  объём без хвоста нулей: 420 → «420», 12.5 → «12,5»;
    С.8  в карточке прайса строка появляется отдельным элементом под ценой;
    С.9  у запрещённого себе вида строки происхождения нет;
    С.10 регресс 181.10: priceDelta берёт avg_usd приоритетно перед справочником.

  Запуск: node стенд_экран_181_4.js <сборка.html>
  Обязан падать на 181.14 и проходить на 181.15.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_15.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const виды = [
  { code:'ML-01', name:'Малярка стен', section:'Малярные', unit:'м²', base_usd:3, active:true,
    avg_usd:4.18, avg_n:6, avg_vol:420, avg_anchor:true },
  { code:'ML-02', name:'Малярка потолка', section:'Малярные', unit:'м²', base_usd:3.2, active:true,
    avg_usd:5.00, avg_n:11, avg_vol:12.5, avg_anchor:false },
  { code:'ML-03', name:'Грунтовка', section:'Малярные', unit:'м²', base_usd:1, active:true,
    avg_usd:1.10, avg_n:0, avg_vol:0, avg_anchor:true },
  { code:'ML-04', name:'Шпаклёвка', section:'Малярные', unit:'м²', base_usd:2, active:true },
  { code:'ML-05', name:'Побелка', section:'Малярные', unit:'м²', base_usd:2, active:true,
    avg_usd:2.5, avg_n:1, avg_vol:30, avg_anchor:false },
  { code:'ML-06', name:'Покраска труб', section:'Малярные', unit:'шт', base_usd:5, active:true,
    avg_usd:5, avg_n:2, avg_vol:8, avg_anchor:false },
  { code:'ML-07', name:'Обои', section:'Малярные', unit:'м²', base_usd:4, active:true,
    avg_usd:4, avg_n:5, avg_vol:100, avg_anchor:false },
  { code:'ML-08', name:'Плинтус', section:'Малярные', unit:'пог.м', base_usd:2, active:true,
    avg_usd:2, avg_n:21, avg_vol:300, avg_anchor:false }
];
const прайс = виды.map(k => ({ code:k.code, name:k.name, unit:k.unit, price_usd: 4.60, active: k.code!=='ML-05' }));

const данные = () => ({ ok:true, role:'crew', kind:'crew', title:'Стенд средней',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Бригадир', object_verified:true, objectVia:'key',
  rooms:[], elements:[], adjacency:[], works:[], catalog:{ kinds: виды, price: прайс }, price: прайс,
  access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[], settings:{},
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 8700 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport: { width: 420, height: 900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof avgHint === 'function');
  t('функция avgHint существует', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const r = await page.evaluate(() => ({
    нет:      avgHint('ML-04'),
    полная:   avgHint('ML-01'),
    безЯкоря: avgHint('ML-02'),
    безРабот: avgHint('ML-03'),
    одна:     avgHint('ML-05'),
    две:      avgHint('ML-06'),
    пять:     avgHint('ML-07'),
    двадцать: avgHint('ML-08'),
    дельта1:  priceDelta('ML-01'),
    дельта4:  priceDelta('ML-04')
  }));

  t('С.1 средней нет → строки нет', r.нет === '', 'вернулось: ' + JSON.stringify(r.нет));
  t('С.2 средняя названа числом', /4[.,]18\s*\$/.test(r.полная), r.полная);
  t('С.2 названы работы и объём', /6 работ/.test(r.полная) && /420/.test(r.полная), r.полная);
  t('С.2 названа единица объёма', /420 м²/.test(r.полная), r.полная);
  t('С.3 якорь жив → сказано о стартовой цене', /стартовая цена ещё учитывается/.test(r.полная), r.полная);
  t('С.4 якорь мёртв → о стартовой цене молчим', !/стартов/.test(r.безЯкоря), r.безЯкоря);
  t('С.5 работ ноль → сказано словами', /ещё нет/.test(r.безРабот), r.безРабот);
  t('С.5 работ ноль → объём не выдуман', !/ 0 /.test(r.безРабот) && !/на 0/.test(r.безРабот), r.безРабот);
  t('С.6 склонение: 1 работа',   r.одна.includes('· 1 работа за'),      r.одна);
  t('С.6 склонение: 2 работы',   r.две.includes('· 2 работы за'),       r.две);
  t('С.6 склонение: 5 работ',    r.пять.includes('· 5 работ за'),       r.пять);
  t('С.6 склонение: 11 работ',   r.безЯкоря.includes('· 11 работ за'),  r.безЯкоря);
  t('С.6 склонение: 21 работа',  r.двадцать.includes('· 21 работа за'), r.двадцать);
  t('С.7 объём 420 без нулей',   /на 420 м²/.test(r.полная),       r.полная);
  t('С.7 объём 12.5 → «12,5»',   /на 12,5 м²/.test(r.безЯкоря),    r.безЯкоря);
  t('С.10 priceDelta берёт avg_usd (4.60 против 4.18 → ▲ 10 %)',
     /▲/.test(r.дельта1) && /10\s*%/.test(r.дельта1), r.дельта1);
  t('С.10 без avg_usd priceDelta считает от справочника (4.60 против 2 → ▲ 130 %)',
     /▲/.test(r.дельта4) && /130\s*%/.test(r.дельта4), r.дельта4);

  // ── карточка прайса целиком ────────────────────────────────────────────
  const карт = await page.evaluate(() => {
    const h = (typeof SCREENS === 'object' && SCREENS.book) ? SCREENS.book() : '';
    const d = document.createElement('div'); d.innerHTML = h;
    const строки = [...d.querySelectorAll('.work')];
    const найти = code => строки.find(x => (x.textContent || '').includes(code));
    const с1 = найти('ML-01'), с5 = найти('ML-05'), с4 = найти('ML-04');
    const подстрока = el => el ? [...el.querySelectorAll('.sub')].map(x=>x.textContent).join(' ~ ') : '(нет карточки)';
    return { длина: h.length, есть1: !!с1, ML01: подстрока(с1), ML05: подстрока(с5), ML04: подстрока(с4) };
  });
  t('С.8 экран прайса построился', карт.длина > 500 && карт.есть1, 'длина ' + карт.длина);
  t('С.8 строка происхождения в карточке', /средняя приложения 4,18|средняя приложения 4.18/.test(карт.ML01), карт.ML01);
  t('С.9 у запрещённого себе вида строки нет', !/средняя приложения/.test(карт.ML05), карт.ML05);
  t('С.9 у вида без средней строки нет',       !/средняя приложения/.test(карт.ML04), карт.ML04);

  console.log('\n=== 181.15 · из чего средняя ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
