/*
  Стенд 181.30 — ни один экран не падает ни в одной роли.

  Повод: прогон всех экранов по ролям 23.08. `money` в роли работника дал
  исключение «Cannot read properties of undefined (reading 'received_usd')» —
  блок `my_money` в ответе отсутствовал, а код читал его поле без проверки.
  Экран не пустел, а рушился: человек видел белое поле вместо денег.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 ни один экран не бросает исключение ни в одной из четырёх ролей;
    С.2 экран денег работника без блока выплат строится;
    С.3 отсутствие блока названо словами, а не выдано за ноль;
    С.4 «Получено» показывает прочерк, а не «0 $»;
    С.5 при живом блоке экран прежний и число на месте;
    С.6 остальные числа экрана считаются и без блока выплат.

  Запуск: node стенд_роли-без-падений_181.js <сборка.html>
  Обязан падать на 181.29 и проходить на 181.30.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_30.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const работы = [
  { code:'ZL-01', room:'Зал (пом. 5)', section:'Малярка', name:'Стены', unit:'м²', qty:40,
    status:'Готово', progress:100, dur:2, note:'вид ML-22', price_alloc_usd:80, price_contractor_usd:70, updated:'2026-08-01' }
];
const данные = () => ({ ok:true, role:'admin', kind:'admin', title:'Стенд ролей',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Тест', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал (пом. 5)', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works: работы,
  catalog:{ kinds:[{ code:'ML-22', section:'Малярка', name:'Стены', unit:'м²', base_usd:2, active:true }],
            price:[{ who:'Ю', code:'ML-22', name:'Стены', unit:'м²', price_usd:2, active:true }] },
  price:[], access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{ 'Договор_USD':200, 'Оплачено_за_работу_USD':100 },
  my_money: null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9900 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1300);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  /* С.1 — общий прогон: четыре роли × одиннадцать экранов. Экран «Бригада»
     пропущен: его данные грузятся отдельной веткой и в моке их нет. */
  const прогон = await page.evaluate(() => {
    const роли = [['admin','admin'], ['owner','owner'], ['foreman','foreman'], ['hand','worker']];
    const экраны = ['home','works','accept','prices','book','profile','object','money','deal','terms','changes'];
    const сохрK = D.kind, сохрR = D.role, из = [];
    for(const [k, r] of роли){
      D.kind = k; D.role = r;
      for(const s of экраны){
        try{ if(SCREENS[s]) SCREENS[s](); }
        catch(e){ из.push(k + '/' + s + ': ' + e.message); }
      }
    }
    D.kind = сохрK; D.role = сохрR;
    return из;
  });
  t('С.1 ни один экран не падает ни в одной роли', прогон.length === 0, прогон.join(' | '));

  const без = await page.evaluate(() => {
    const сохрK = D.kind, сохрR = D.role, сохрM = D.my_money;
    D.kind = 'hand'; D.role = 'worker'; D.my_money = null;
    let h = ''; try{ h = SCREENS.money(); }catch(e){ h = 'ОШИБКА: ' + e.message; }
    D.kind = сохрK; D.role = сохрR; D.my_money = сохрM;
    return h;
  });
  /* Лишний аргумент здесь однажды сделал проверку вечно зелёной: вторым
     параметром t() шла стрелка `h => h`, а она truthy всегда. Стенд обязан
     проверяться на сборке, где дефект есть, — иначе он проверяет себя. */
  t('С.2 экран денег работника без блока выплат строится',
     без.indexOf('ОШИБКА') !== 0 && без.length > 200, без.slice(0, 90));
  t('С.3 отсутствие блока названо словами',
     /Сервер не прислал ваши выплаты/.test(без), без.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').slice(0,120));
  t('С.4 «Получено» показывает прочерк, а не ноль',
     /Получено<\/div><div class="v ok"[^>]*>—</.test(без.replace(/\s+/g,'')) || />—</.test(без),
     (без.match(/Получено[\s\S]{0,120}/) || [''])[0].replace(/<[^>]*>/g,' ').replace(/\s+/g,' '));
  t('С.6 остальные числа посчитаны', /Договор/.test(без) && /Принято заказчиком/.test(без), 'числа пропали');

  const с = await page.evaluate(() => {
    const сохрK = D.kind, сохрR = D.role, сохрM = D.my_money;
    D.kind = 'hand'; D.role = 'worker'; D.my_money = { received_usd: 55 };
    let h = ''; try{ h = SCREENS.money(); }catch(e){ h = 'ОШИБКА: ' + e.message; }
    D.kind = сохрK; D.role = сохрR; D.my_money = сохрM;
    return h;
  });
  t('С.5 при живом блоке число на месте и плашки нет',
     /55/.test(с) && !/Сервер не прислал/.test(с), с.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').slice(0,120));

  console.log('\n=== 181.30 · роли без падений ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
