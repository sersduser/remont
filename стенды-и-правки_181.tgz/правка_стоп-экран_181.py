# -*- coding: utf-8 -*-
"""Панель: при остановленном обновлении экран перестаёт притворяться рабочим.

Дефект пойман живым проходом Дмитрия 22.08 (скрины 1310 и 1312). Панель честно
поймала протухший пропуск Telegram и сказала об этом полосой внизу — правка 159.3
сработала. Но экран ПОД полосой продолжал принимать нажатия: плитки открывались,
данные не обновлялись, и человек прочитал это как «страница зависла» (его слова).

Лечение — два хода:
  1. Поверх экрана ложится маска, которая перехватывает нажатия и подсвечивает
     полосу вместо молчаливого «ничего не произошло». Полоса остаётся выше маски.
  2. В полосу добавляется кнопка «Закрыть панель»: одно нажатие вместо инструкции
     «закройте крестиком и откройте заново». Если клиент Telegram закрытия не даёт —
     кнопка не рисуется, текст остаётся прежним.

Идемпотентна. Запуск: python3 правка_стоп-экран_181.py <файл.html>
"""
import hashlib, sys
from pathlib import Path

МАРКЕР = "staleMask"

ИЗ = """  b.innerHTML = '<b>Обновление остановлено.</b> ' + esc(staleMsg());
  document.body.appendChild(b);
}"""

В = """  b.innerHTML = '<b>Обновление остановлено.</b> ' + esc(staleMsg());
  document.body.appendChild(b);

  /* [181] Экран под полосой больше не притворяется рабочим. Повод — живой проход
     22.08: панель сказала «обновление остановлено», а плитки продолжали
     нажиматься, и человек прочитал это как зависание. Маска перехватывает
     нажатие и подсвечивает полосу — молчаливого «ничего не произошло» больше нет. */
  if(!document.getElementById("staleMask")){
    const m = document.createElement("div");
    m.id = "staleMask";
    m.style.cssText = "position:fixed;left:0;right:0;top:0;bottom:0;z-index:9997;background:rgba(0,0,0,.35)";
    m.onclick = function(){
      const п = document.getElementById("staleBar");
      if(!п) return;
      п.style.transition = "none"; п.style.filter = "brightness(1.35)";
      setTimeout(() => { п.style.transition = ".25s"; п.style.filter = ""; }, 160);
    };
    document.body.appendChild(m);
  }

  /* Кнопка вместо инструкции: закрыть панель одним нажатием, дальше человек
     открывает её кнопкой «Смета» в чате с ботом — как и сказано в тексте. */
  try{
    if(tg && typeof tg.close === "function"){
      const к = document.createElement("button");
      к.textContent = "Закрыть панель";
      к.style.cssText = "margin-top:10px;width:100%;padding:11px;border:0;border-radius:10px;" +
        "font-size:15px;font-weight:600;background:#1c1c1e;color:#fff";
      к.onclick = function(){ try{ tg.close(); }catch(e){} };
      b.appendChild(к);
    }
  }catch(e){}
}"""

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    ф = Path(sys.argv[1]); исходный = ф.read_text(encoding="utf-8")
    if МАРКЕР in исходный:
        print("уже применено:", ф.name); return 0
    if ИЗ not in исходный:
        print("ОТКАЗ: не найден якорь staleStop"); return 3
    т = исходный.replace(ИЗ, В, 1)
    ф.write_text(т, encoding="utf-8")
    print("до :", len(исходный.encode()), "б  sha16", hashlib.sha256(исходный.encode()).hexdigest()[:16])
    print("после:", len(т.encode()), "б  sha16", hashlib.sha256(т.encode()).hexdigest()[:16])
    return 0

sys.exit(main())
