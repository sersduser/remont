/*
  Стенд 181.23 — цены работ берутся из прайса исполнителя.

  Повод: живой проход 23.08. Экран «Цены Юрия» предлагал диктовать ставку
  голосом или разносить сумму договора, но не предлагал взять цену из прайса —
  при том, что прайс заполнен, вид у работы проставлен, объём известен.
  На боевом объекте это 110 работ из 127 на 4 639,36 $.

  Что меряется:
    С.0 страница поднялась без ошибок JS;
    С.1 план строится: цена = объём × ставка прайса;
    С.2 работа с чужой единицей в план не идёт и названа причиной;
    С.3 «п.м.» и «пог.м» — одна единица, такая работа в план ИДЁТ;
    С.4 вида нет в прайсе / строка без цены / нет объёма — свои причины;
    С.5 работа с уже заданной ценой исполнителя не трогается;
    С.6 сумма плана считается по объёмам, а не по числу строк;
    С.7 кнопка есть на экране и называет число, сумму и разницу с договором;
    С.8 кнопки нет, когда ставить нечего;
    С.9 регресс: голосовой ввод и разнесение суммы на месте.

  Запуск: node стенд_цены-из-прайса_181.js <сборка.html>
  Обязан падать на 181.22 и проходить на 181.23.
*/
const { chromium } = require('playwright');
const path = require('path'); const http = require('http'); const fs = require('fs');
const FILE = path.resolve(process.argv[2] || '/tmp/panel_181_23.html');
const ok = [], bad = [];
const t = (n, c, e) => (c ? ok : bad).push(n + (c ? '' : ' — ' + (e || 'не выполнено')));
const KEY = 'bbccddee-8888-4888-8888-bbccddeeff00';

const виды = [
  { code:'ML-22', section:'Малярка',    name:'Стены: покраска',        unit:'м²',    base_usd:1.5,  active:true },
  { code:'SN-05', section:'Сантехника', name:'Разводка водоснабжения', unit:'пог.м', base_usd:2.95, active:true },
  { code:'OK-06', section:'Окна',       name:'Откосы оконные',         unit:'п.м.',  base_usd:4.89, active:true },
  { code:'ZZ-99', section:'Прочее',     name:'Строка без цены',        unit:'шт',    base_usd:0,    active:true },
  { code:'NP-01', section:'Прочее',     name:'Вида нет в прайсе',      unit:'шт',    base_usd:3,    active:true }
];
const прайс = [
  { who:'Ю', code:'ML-22', name:'Стены: покраска',        unit:'м²',    price_usd:2.00, active:true },
  { who:'Ю', code:'SN-05', name:'Разводка водоснабжения', unit:'пог.м', price_usd:2.95, active:true },
  { who:'Ю', code:'OK-06', name:'Откосы оконные',         unit:'пог.м', price_usd:4.89, active:true },
  { who:'Ю', code:'ZZ-99', name:'Строка без цены',        unit:'шт',    price_usd:null, active:true }
];
const работы = [
  { code:'ZL-01', room:'Зал (пом. 5)', section:'Малярка',    name:'Стены: покраска',   unit:'м²',    qty:40, status:'Не начато', note:'вид ML-22', price_alloc_usd:60, price_contractor_usd:null },
  { code:'VN-14', room:'Ванная',       section:'Сантехника', name:'Разводка',          unit:'компл', qty:1,  status:'Не начато', note:'вид SN-05', price_alloc_usd:95, price_contractor_usd:null },
  { code:'OK-01', room:'Зал (пом. 5)', section:'Окна',       name:'Откосы',            unit:'п.м.',  qty:6,  status:'Не начато', note:'вид OK-06', price_alloc_usd:28, price_contractor_usd:null },
  { code:'ZZ-01', room:'Зал (пом. 5)', section:'Прочее',     name:'Строка без цены',   unit:'шт',    qty:2,  status:'Не начато', note:'вид ZZ-99', price_alloc_usd:10, price_contractor_usd:null },
  { code:'NP-01', room:'Зал (пом. 5)', section:'Прочее',     name:'Вида нет в прайсе', unit:'шт',    qty:3,  status:'Не начато', note:'вид NP-01', price_alloc_usd:9,  price_contractor_usd:null },
  { code:'NV-01', room:'Зал (пом. 5)', section:'Прочее',     name:'Без вида',          unit:'шт',    qty:1,  status:'Не начато', note:'',          price_alloc_usd:5,  price_contractor_usd:null },
  { code:'NQ-01', room:'Зал (пом. 5)', section:'Малярка',    name:'Без объёма',        unit:'м²',    qty:0,  status:'Не начато', note:'вид ML-22', price_alloc_usd:0,  price_contractor_usd:null },
  { code:'ZD-01', room:'Зал (пом. 5)', section:'Малярка',    name:'Уже с ценой',       unit:'м²',    qty:10, status:'Не начато', note:'вид ML-22', price_alloc_usd:15, price_contractor_usd:25 }
];

const данные = () => ({ ok:true, role:'foreman', kind:'foreman', title:'Стенд цен',
  object_id:'019ff52d-f8c1-7468-a4eb-4db7ec41fba7', who:'Юрий', object_verified:true, objectVia:'key',
  rooms:[{ code:'ZL', name:'Зал (пом. 5)', kind:'жилая', floor_m2:16, perimeter_m:16, height_m:2.8, wall_m2:39, ceiling_m2:16 }],
  elements:[], adjacency:[], works: работы, catalog:{ kinds: виды, price: прайс }, price: прайс,
  access:[], modifiers:[], docs:[], drafts:[], crew:[], payments:[], changes:[],
  settings:{ 'Договор_USD': 200, 'Коэффициент_K': 1 },
  my_money:null, materials:[], log:[], accepts:[], extras:[] });

(async () => {
  const порт = 9300 + (process.pid % 60);
  const сервер = http.createServer((q, s) => {
    s.writeHead(200, { 'Content-Type':'text/html; charset=utf-8' }); s.end(fs.readFileSync(FILE, 'utf-8'));
  }).listen(порт);
  const br = await chromium.launch();
  const page = await br.newPage({ viewport:{ width:420, height:900 } });
  const ошибки = []; page.on('pageerror', e => ошибки.push(String(e && e.message)));
  await page.route('https://n8n.nc-lab.uz/**', route =>
    route.fulfill({ status:200, contentType:'application/json', body: JSON.stringify(данные()) }));
  await page.goto(`http://127.0.0.1:${порт}/panel?key=${KEY}`, { waitUntil:'domcontentloaded' });
  await page.waitForTimeout(1400);
  t('С.0 страница поднялась без ошибок JS', ошибки.length === 0, ошибки.slice(0,2).join(' | '));

  const есть = await page.evaluate(() => typeof pricesFromBookPlan === 'function' && typeof pricesFromBookAsk === 'function');
  t('функции pricesFromBookPlan и pricesFromBookAsk существуют', есть);
  if (!есть) { console.log('\nПРОВАЛ: ' + bad.join('\n')); await br.close(); сервер.close(); process.exit(1); }

  const r = await page.evaluate(async () => {
    if(!D.catalog) { try{ await loadCatalog(); }catch(e){} }
    const p = pricesFromBookPlan();
    return { коды: p.план.map(x => x.code), цены: {}, сумма: p.сумма, пропуск: p.пропуск,
             значения: p.план.reduce((a, x) => (a[x.code] = x.value, a), {}) };
  });
  t('С.1 план: цена = объём × ставка (40 м² × 2,00 = 80)',
     r.значения['ZL-01'] === 80, JSON.stringify(r.значения));
  t('С.2 работа с чужой единицей в план не идёт',
     r.коды.indexOf('VN-14') < 0 && r.пропуск.единица === 1, JSON.stringify(r.пропуск));
  t('С.3 «п.м.» и «пог.м» — одна единица, работа в плане (6 × 4,89 = 29,34)',
     r.коды.indexOf('OK-01') >= 0 && r.значения['OK-01'] === 29.34, JSON.stringify(r.значения));
  t('С.4 строка прайса без цены — своя причина',
     r.коды.indexOf('ZZ-01') < 0 && r.пропуск.нетЦены === 1, JSON.stringify(r.пропуск));
  t('С.4-bis вида нет в прайсе — своя причина',
     r.коды.indexOf('NP-01') < 0 && r.пропуск.нетСтроки === 1, JSON.stringify(r.пропуск));
  t('С.4-ter вид не указан — своя причина',
     r.коды.indexOf('NV-01') < 0 && r.пропуск.нетВида === 1, JSON.stringify(r.пропуск));
  t('С.4-quater нет объёма — своя причина',
     r.коды.indexOf('NQ-01') < 0 && r.пропуск.нетОбъёма === 1, JSON.stringify(r.пропуск));
  t('С.5 работа с уже заданной ценой не трогается',
     r.коды.indexOf('ZD-01') < 0, JSON.stringify(r.коды));
  t('С.6 сумма плана: 80 + 29,34 = 109,34',
     Math.abs(r.сумма - 109.34) < 0.005, 'сумма = ' + r.сумма);

  const h = await page.evaluate(() => SCREENS.prices());
  t('С.7 кнопка есть и называет число', /Взять цены из прайса/.test(h) && /закрывает <b>2<\/b> работы/.test(h),
     (h.match(/Ваш прайс закрывает[^<]{0,80}/) || [''])[0]);
  /* fmt округляет до доллара — «109 USD», и для суммы прайса этого довольно:
     копейки здесь ложная точность, решение принимается по порядку величины. */
  t('С.7-bis названа сумма и разница с договором',
     /109 USD/.test(h.replace(/&nbsp;/g,' ')) && /на 45 % дешевле/.test(h),
     (h.match(/USD<\/b>[^<]{0,90}/) || [''])[0]);
  t('С.9 регресс: голос и разнесение на месте',
     /Сказать ставку/.test(h) && /Только пустым/.test(h), 'прежние пути пропали');

  const пусто = await page.evaluate(() => {
    const было = D.catalog.price;
    D.catalog.price = [];
    const h = SCREENS.prices();
    D.catalog.price = было;
    return h;
  });
  t('С.8 ставить нечего — кнопки нет', !/Взять цены из прайса/.test(пусто), 'кнопка показана зря');

  console.log('\n=== 181.23 · цены из прайса ===');
  ok.forEach(x => console.log('  ✓ ' + x));
  bad.forEach(x => console.log('  ✗ ' + x));
  console.log(`\nитог: ${ok.length}/${ok.length + bad.length}`);
  await br.close(); сервер.close();
  process.exit(bad.length ? 1 : 0);
})();
